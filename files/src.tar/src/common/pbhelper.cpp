#include "pbhelper.h"

namespace strangertalk { namespace guessgame { namespace common {

bool ProtoBufHelper::PbSerilizeToString(Message* message, std::string& pbstr) {
  bool ret = false;
  YY_DEBUG_LOG("[+]ProtoBufHelper::PbSerilizeToString");
  try {
    ret = message->SerializeToString(&pbstr);
    YY_DEBUG_LOG("ProtoBufHelper::PbSerilizeToString:%s",message->DebugString().c_str());
  }
  catch (google::protobuf::FatalException& ex)  {
    YY_LOG(LOG_ERR, "ProtoBufHelper::PbSerilizeToString: failed to Serialize Response, somthing error, err:%s,",ex.what());
  }
  YY_DEBUG_LOG("[-]ProtoBufHelper::PbSerilizeToString,ret:%d",ret);
  return ret;
}

bool ProtoBufHelper::StringParseToPb(const std::string& pbstr, Message* message) {
  YY_DEBUG_LOG("[+]ProtoBufHelper::StringParseToPb");
  bool isParse = false;
  try {
    isParse = message->ParseFromString(pbstr);
  } 
  catch (google::protobuf::FatalException& ex) {
    YY_LOG(LOG_ERR,"ProtoBufHelper::StringParseToPb(),parse protobuf error:%s",ex.what());
  }
  YY_DEBUG_LOG("[+]ProtoBufHelper::StringParseToPb,ret:%d",isParse);
  return isParse;
}

}}}
