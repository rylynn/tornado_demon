#include "appserverconf.h"
#include "utility/srvconfig.h"
#include "log/logger.h"
#include "serverconf.pb.h"

using ::yy::common::utility::SrvConfig;
using namespace protocol::strangertalk::guessgame_config;

namespace strangertalk { namespace guessgame { namespace common {

AppServerConf::AppServerConf() {
	YY_MEMBER_LOG(LOG_INFO,"[+/-]AppServerConf::ctor()");
}

AppServerConf::~AppServerConf() {
	YY_MEMBER_LOG(LOG_INFO,"[+/-]AppServerConf::dector()");
}

bool AppServerConf::Load(const string& path) {
	YY_MEMBER_LOG(LOG_INFO,"[+]AppServerConf::Load(),path:%s",path.c_str());
	bool ret = true;
	if (SrvConfig<GuessGameConfig>::Singleton().Load(path) != 0 || SrvConfig<GuessGameConfig>::Singleton().GetConfig().IsInitialized() == false) {
		YY_MEMBER_LOG(LOG_ERR,"AppServerConf::Load(),Config Load Error");
		ret = false;
	} else {
		YY_MEMBER_LOG(LOG_INFO,"AppServerConf::Load(), config_str:%s",SrvConfig<GuessGameConfig>::Singleton().GetConfig().ShortDebugString().c_str())
	}
	YY_MEMBER_LOG(LOG_INFO,"[-]AppServerConf::Load(),ret:%d",ret);
	return ret;
}

const ThreadGroupSet& AppServerConf::thread_group_set() const {
	YY_MEMBER_DEBUG_LOG("[+]AppServerConf::thread_group_set()");
	static ThreadGroupSet s_thread_group_set;
	const GuessGameConfig& real_config = SrvConfig<GuessGameConfig>::Singleton().GetConfig();
	for (int i = 0; i < real_config.thread_group().size(); i++) {
		const protocol::strangertalk::guessgame_config::ThreadGroup& pb_thread_group = real_config.thread_group(i);
		ThreadGroup thread_group;
		thread_group.thread_count = pb_thread_group.thread_count();
		thread_group.thread_threshold = pb_thread_group.thread_threshold();
		thread_group.alert_queue_size = pb_thread_group.alert_queue_size();
		thread_group.max_queue_size = pb_thread_group.max_queue_size();
		s_thread_group_set[pb_thread_group.name()] = thread_group;
	} 
	YY_MEMBER_DEBUG_LOG("[-]AppServerConf::thread_group_set(), size:%zu",s_thread_group_set.size());
	return s_thread_group_set;
}

void AppServerConf::GetRedisClusterAddr(SrvAddress& addr) {
	const GuessGameConfig& real_config = SrvConfig<GuessGameConfig>::Singleton().GetConfig();
	addr.ip = real_config.redis_cluster_addr().ip();
	addr.port = real_config.redis_cluster_addr().port();
	YY_MEMBER_DEBUG_LOG("[+/-]AppServerConf::GetRedisClusterAddr(),ip:%s,port:%u",addr.ip.c_str(),addr.port);
}

void AppServerConf::GetCulRedisAddr(SrvAddress& addr) {
	const GuessGameConfig& real_config = SrvConfig<GuessGameConfig>::Singleton().GetConfig();
	addr.ip = real_config.cul_redis_addr().ip();
	addr.port = real_config.cul_redis_addr().port();
	YY_MEMBER_DEBUG_LOG("[+/-]AppServerConf::GetCulRedisAddr(),ip:%s,port:%u",addr.ip.c_str(),addr.port);
}

string AppServerConf::WordsConfPath() {
	const GuessGameConfig& real_config = SrvConfig<GuessGameConfig>::Singleton().GetConfig();
	YY_MEMBER_DEBUG_LOG("[+/-]AppServerConf::WordsConfPath(),path:%s",real_config.words_path().c_str());
	return real_config.words_path();
}

}}}
