/*
	author rylynn_xj
	2015/6/3
*/
#ifndef YY_STRANGERTALK_GUESSGAME_COMMON_PBHELPER_H_
#define YY_STRANGERTALK_GUESSGAME_COMMON_PBHELPER_H_
#include <string>
#include <google/protobuf/message.h>
#include "log/logger.h"

namespace strangertalk { namespace guessgame { namespace common {

using namespace google::protobuf;

class ProtoBufHelper {
public:
  static bool PbSerilizeToString(Message* message, std::string& pbstr);
  static bool StringParseToPb(const std::string& pbstr, Message* message);
};
}}}
#endif
