/*
 * author:rylynn_xj
 * date:2015/8/19
 */

#ifndef YY_STRANGERTALK_GUESSGAME_COMMON_APPSERVERCONF_H_
#define YY_STRANGERTALK_GUESSGAME_COMMON_APPSERVERCONF_H_

#include <inttypes.h>
#include <map>
#include <vector>
#include <string>

using namespace std;

namespace strangertalk { namespace guessgame { namespace common {

struct ThreadGroup {
	uint32_t thread_count;
	uint32_t thread_threshold;
	uint32_t max_queue_size;
	uint32_t alert_queue_size;

	ThreadGroup():thread_count(10),thread_threshold(20),max_queue_size(3000),alert_queue_size(1500){;}
};

typedef map< string/*name*/, ThreadGroup > ThreadGroupSet;

struct SrvAddress {
	string ip;
	uint16_t    port;
	SrvAddress(): ip("0"), port(0){;}
};

class AppServerConf {
public:

	static AppServerConf& Singleton()
	{
		static AppServerConf singleton_;
		return singleton_;
	}

  bool Load(const string& path);
		
	const ThreadGroupSet& thread_group_set() const;
	string WordsConfPath();
	void GetRedisClusterAddr(SrvAddress& addr);
	void GetCulRedisAddr(SrvAddress& addr); 

private:
	AppServerConf();
	~AppServerConf();
//private:
//	map<string, ThreadGroup> thread_group_map_;
//	SrvAddress cul_redis_address_;
//	SrvAddress redis_cluster_address_;
};

}}}
#endif
