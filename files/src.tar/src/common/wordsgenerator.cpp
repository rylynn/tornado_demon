#include "wordsgenerator.h"
#include <stdlib.h>
#include "shareconst.h"
#include <time.h>
#include "appserverconf.h"
#include "log/logger.h"
#include "log/returncode.h"

namespace strangertalk { namespace guessgame { namespace common {

WordsGenerator::WordsGenerator() {
	YY_MEMBER_LOG(LOG_INFO,"[+/-]WordsGenerator::ctor()");
}

WordsGenerator::~WordsGenerator() {
	YY_MEMBER_LOG(LOG_INFO,"[+/-]WordsGenerator::dector()");
}

bool WordsGenerator::Init() {
	YY_MEMBER_LOG(LOG_INFO,"[+]WordsGenerator::LoadWords(),path:%s",AppServerConf::Singleton().WordsConfPath().c_str());
	words_cache_vec_.clear();
	FILE* fp = fopen(AppServerConf::Singleton().WordsConfPath().c_str(),"r");
	bool ret = true;
	if (fp == NULL) {
		YY_MEMBER_LOG(LOG_ERR,"WordsGenerator::LoadWords(),open file error");
		ret = false;
	} else {
		char word[30] = {0};
		words_cache_vec_.reserve(kWordsCount);
		while (fgets(word,30,fp) !=	NULL) {
			words_cache_vec_.push_back(word);
		}
		fclose(fp);
	}
	YY_MEMBER_LOG(LOG_INFO,"[-]WordsGenerator::LoadWords(),size:%zu",words_cache_vec_.size());
	return ret;
}

int WordsGenerator::GetRandomWordNotSame(std::set<string>& already_userd_set, string& word) {
	YY_MEMBER_DEBUG_LOG("[+]WordsGenerator::GetRandomWordNotSame()");
	int ret = kReturnOk;
	if (words_cache_vec_.size() == 0) {
		ret = kReturnNotExist;
		YY_MEMBER_DEBUG_LOG("[-]WordsGenerator::GetRandomWordNotSame(),ret:%d",ret);
		return ret;
	}

	if (already_userd_set.empty()) {
		word = words_cache_vec_[GetRandNum()%words_cache_vec_.size()];
	} else {
		while (true) {
			word = words_cache_vec_[GetRandNum()%words_cache_vec_.size()];
			if (already_userd_set.find(word) == already_userd_set.end()) {
				break;
			}
		}
	}
	YY_MEMBER_DEBUG_LOG("[-]WordsGenerator::GetRandomWordNotSame(),ret:%d",ret);
	return ret;
}

int WordsGenerator::GetRandomWordsNotSame(std::set<string>& already_userd_set, vector<string> words, uint32_t count) {
	YY_MEMBER_DEBUG_LOG("[+]WordsGenerator::GetRandomWordsNotSame(),count:%u",count);
	int ret = kReturnOk;
	if (words_cache_vec_.size() == 0) {
		ret = kReturnNotExist;
		YY_MEMBER_DEBUG_LOG("[-]WordsGenerator::GetRandomWordsNotSame,ret:%d",ret);
		return ret;
	}
	string word;

	if (already_userd_set.empty()) {
		while (count--) {
			word = words_cache_vec_[GetRandNum()%words_cache_vec_.size()];
			words.push_back(word);
		}
	} else {
		while (count--) {
			while (true) {
				word = words_cache_vec_[GetRandNum()%words_cache_vec_.size()];
				if (already_userd_set.find(word) == already_userd_set.end()) {
					words.push_back(word);
					break;
				}
		}	
		}
	}
	YY_MEMBER_DEBUG_LOG("[+]WordsGenerator::GetRandomWordsNotSame()");
	return ret;
}

int WordsGenerator::GetRandomWord(string& word) {
	YY_MEMBER_DEBUG_LOG("[+]WordsGenerator::GetRandomWord()");

	int ret = kReturnOk;
	if (words_cache_vec_.size() == 0) {
		ret = kReturnNotExist;
		YY_MEMBER_DEBUG_LOG("[-]WordsGenerator::GetRandomWord(),ret:%d",ret);
		return ret;
	}

	word = words_cache_vec_[GetRandNum()%words_cache_vec_.size()];
	YY_MEMBER_DEBUG_LOG("[-]WordsGenerator::GetRandomWord()");
	return ret;
}

uint32_t WordsGenerator::GetRandNum() {
	YY_MEMBER_DEBUG_LOG("[+]WordsGenerator::GetRandNum()");
	srandom(time(NULL));
	uint32_t randnum = random();
	YY_MEMBER_DEBUG_LOG("[-]WordsGenerator::GetRandNum(),randnum:%u",randnum);
	return randnum;
}

}}}
