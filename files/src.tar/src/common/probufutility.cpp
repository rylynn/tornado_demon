/* 
 * File:   probufutility.cpp
 * Author: luoshaoqi
 * 
 * Created on 2015年6月24日, 下午3:09
 */

#include "probufutility.h"
#include "log/logger.h"

namespace common {
  
bool ProbufUtility::ParseFromString(const std::string& message, ::google::protobuf::Message& _result) 
{
  YY_DEBUG_LOG("[+]ProbufUtility::ParseFromString(%s)", message.c_str());  
  bool ret = false;
  try {
    ret = _result.ParseFromString(message);
  } catch (google::protobuf::FatalException& ex) {
    YY_LOG(LOG_ERR, "ProbufUtility::ParseFromString(),parse protobuf error:%s",ex.what());
  }
  YY_DEBUG_LOG("[-]ProbufUtility::ParseFromString() => return %s", ret?"true":"false");    
  return ret;
}

bool ProbufUtility::SerializeToString(const ::google::protobuf::Message& message, std::string& _result)
{
  YY_DEBUG_LOG("[+]ProbufUtility::SerializeToString()");  
  bool ret = false;
  try {
    ret = message.SerializeToString(&_result);
  } catch (google::protobuf::FatalException& ex) {
    YY_LOG(LOG_ERR, "ProbufUtility::SerializeToString(),parse protobuf error:%s",ex.what());
  }
  YY_DEBUG_LOG("[-]ProbufUtility::SerializeToString() => return %s", ret?"true":"false");    
  return ret;
}
  
}
