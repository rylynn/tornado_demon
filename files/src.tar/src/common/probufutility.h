/* 
 * File:   probufutility.h
 * Author: luoshaoqi
 *
 * Created on 2015年6月24日, 下午3:09
 */

#ifndef COMMON_PROBUFUTILITY_H_
#define	COMMON_PROBUFUTILITY_H_

#include <string>
#include <google/protobuf/message.h>

namespace common {

class ProbufUtility {
public:
  static bool ParseFromString(const std::string& message, ::google::protobuf::Message& _result);
  static bool SerializeToString(const ::google::protobuf::Message& message, std::string& _result);
};

}

#endif	/* COMMON_PROBUFUTILITY_H_ */

