#ifndef YY_STRANGERTALK_GUESSGAME_COMMON_SHARECONST_H_
#define YY_STRANGERTALK_GUESSGAME_COMMON_SHARECONST_H_
#include <string>

using std::string;
enum NextStepOperator {
	kCorrect = 0,
	kSkip = 1
};

static const string kNonBlockThreadGroup = "unblock_thread_group";
static const string kBlockThreadGroup = "block_thread_group";

static const int kReturnOk = 0;
static const int kReturnSysErr = -1;
static const int kReturnExist = 1;
static const int kReturnNotExist = 2;
static const int kReturnPermissionDeny = 3;
static const int kReturnNotEnoughPeople = 4;

static const int kWordsCount = 20000;

static const string kGuessGameSrvPrefix = "guessgamesrv:";
static const string kRoomUserPrefix = "room_srv:roomuser:";
static const std::string kComperePrefix =  "room_srv:compere:";

#endif
