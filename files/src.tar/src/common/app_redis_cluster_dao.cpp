#include <map>

#include "app_redis_cluster_dao.h"
#include "log/logger.h"
#include "log/returncodelog.h"
#include <boost/lexical_cast.hpp>
#include "json_protobuf_converter.h"
#include "shareconst.h"
#include "appserverconf.h"
#include "roomserverandredis.pb.h"

using ::yy::common::utility::JsonProtobufConverter;
using namespace ::yy::common::log;
using namespace ::protocol::strangertalk::roomserver::redis;

#define ON_MAIXU 3

namespace strangertalk { namespace guessgame { namespace common {

AppRedisClusterDao::AppRedisClusterDao() {
	YY_MEMBER_DEBUG_LOG("[+/-]AppRedisClusterDao::AppRedisClusterDao():ctor()");
}

AppRedisClusterDao::~AppRedisClusterDao() {
	YY_MEMBER_DEBUG_LOG("[+/-]AppRedisClusterDao::AppRedisClusterDao():dector()");
}

bool AppRedisClusterDao::Init() {
	YY_MEMBER_DEBUG_LOG("[+]AppRedisClusterDao::Init()");
	if (!init_)
	{
		SrvAddress redis_cluster_addr;
		AppServerConf::Singleton().GetRedisClusterAddr(redis_cluster_addr);
		sys_redis_cluster_ptr.reset(new SyncRedisClusterClient(redis_cluster_addr.ip,redis_cluster_addr.port));
		init_ = true;
	}
	YY_MEMBER_DEBUG_LOG("[-]AppRedisClusterDao::Init()");
	return init_;
}

int AppRedisClusterDao::GetGameRoundData(GameRoundData& data) {
	YY_MEMBER_DEBUG_LOG("[+]AppRedisClusterDao::GetGameRoundData(),room_id:%u",data.room_id());
	std::string key = kGuessGameSrvPrefix + boost::lexical_cast<string>(data.room_id());
	std::string result;
	int ret =  sys_redis_cluster_ptr->get(key,result);
	if (ret == kReturnOk) {
		ret = JsonProtobufConverter<GameRoundData>::StorageStringToProtobuf( result, data );
	} else {
		YY_MEMBER_LOG(LOG_ERR,"AppRedisClusterDao::GetGameRoundData() error,ret:%d",ret);
	}

	YY_MEMBER_DEBUG_LOG("[-]AppRedisClusterDao::GetGameRoundData()");
	RETURN(ret);
}

int AppRedisClusterDao::SetGameRoundData(const GameRoundData& data) {
	YY_MEMBER_DEBUG_LOG("[+]AppRedisClusterDao::SetGameRoundData(),room_id:%u",data.room_id());
	std::string key = kGuessGameSrvPrefix + boost::lexical_cast<string>(data.room_id());
	string result = JsonProtobufConverter< GameRoundData >::ProtobufToStorageString( data );

	int ret =  sys_redis_cluster_ptr->set(key,result);

	if (ret != kReturnOk) {
		YY_MEMBER_LOG(LOG_ERR,"AppRedisClusterDao::SetGameRoundData() error,ret:%d",ret);
	} 

	YY_MEMBER_DEBUG_LOG("[+]AppRedisClusterDao::SetGameRoundData(),room_id:%u",data.room_id());
	RETURN(ret);
}

int AppRedisClusterDao::DelGameRoundData(uint32_t room_id) {
	YY_MEMBER_DEBUG_LOG("[+]AppRedisClusterDao::DelGameRoundData(),room_id:%u",room_id);
	std::string key = kGuessGameSrvPrefix + boost::lexical_cast<string>(room_id);
	int64_t del_ret = 0;
	int ret = sys_redis_cluster_ptr->del(key,del_ret);
	if (ret >= 0) {
		ret = kReturnOk;
	}
	YY_MEMBER_DEBUG_LOG("[-]AppRedisClusterDao::DelGameRoundData(),room_id:%u",room_id);
	RETURN(ret);
}

int AppRedisClusterDao::GetRoomPeopleList(uint32_t room_id, std::set<uint32_t>& playerlists) {
	YY_MEMBER_DEBUG_LOG("[+]AppRedisClusterDao::GetRoomPeopleList(),room_id:%u",room_id);
	std::string key = kRoomUserPrefix + boost::lexical_cast<string>(room_id);
	std::map<string, string> results;
	int ret = sys_redis_cluster_ptr->hgetall(key,results);
	for (std::map<string,string>::iterator it = results.begin(); it != results.end(); ++it) {
		R_RoomUser r_room_user;	
		if (JsonProtobufConverter<R_RoomUser>::StorageStringToProtobuf(it->second, r_room_user) != 0) 
		{
			ret = kReturnSysErr;
			break;
		}  
		if(r_room_user.identity_type() == ON_MAIXU)
		{
			playerlists.insert(r_room_user.uid());
		} 
	}
	YY_MEMBER_DEBUG_LOG("[-]AppRedisClusterDao::GetRoomPeopleList(),ret:%d",ret);
	return ret;
}

int AppRedisClusterDao::GetCompere(uint32_t room_id, uint32_t& compere_uid) {
	YY_MEMBER_DEBUG_LOG("[+]AppRedisClusterDao::GetCompere(),room_id:%u",room_id);
	int ret = kReturnOk;
	compere_uid = 0;
	string key = kComperePrefix + boost::lexical_cast<string>(room_id);
	string result;
	int ret_get = sys_redis_cluster_ptr->get(key, result);
	if (ret_get == 0) 
	{
		R_Compere compere;
		if (JsonProtobufConverter<R_Compere>::StorageStringToProtobuf(result, compere) != 0) 
		{
			ret = kReturnSysErr;
		}    
		else
		{
			compere_uid = compere.uid();
		}
	} 
	if (ret_get == 1) {
		ret = kReturnNotExist;
	}
	if (ret_get == -1) {
		ret = kReturnSysErr;
	}
	YY_MEMBER_DEBUG_LOG("[-]AppRedisClusterDao::GetCompere(),compere_uid:%u",compere_uid);
	RETURN(ret);
}

}}}

