/**
 *author:rylynn_xj
 *date:2015/8/21
 */

#ifndef YY_STRANGERTALK_GUESSGAME_COMMON_WORDSCACHE_H_
#define YY_STRANGERTALK_GUESSGAME_COMMON_WORDSCACHE_H_

#include <string>
#include <vector>
#include <set>
#include <boost/shared_ptr.hpp>

using boost::shared_ptr;

using std::vector;
using std::string;
using std::set;

namespace strangertalk { namespace guessgame { namespace common {

class WordsGenerator {
public:
	static WordsGenerator& Singleton() {
		static WordsGenerator words_generator_singleton_;
		return words_generator_singleton_;
	}
	
	bool Init();

	int GetRandomWordNotSame(std::set<string>& already_userd_set, string& word);
	int GetRandomWordsNotSame(std::set<string>& already_userd_set, vector<string> words, uint32_t count);
	
	int GetRandomWord(string& word);

private:
	WordsGenerator();
	~WordsGenerator();
	uint32_t GetRandNum();

private:
	vector<string> words_cache_vec_;
};

}}}
#endif
