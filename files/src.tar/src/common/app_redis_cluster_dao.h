/*
 *author:rylynn_xj
 *date:2015/8/20
 * */

#ifndef YY_STRANGERTALK_GUESSGAME_COMMON_APPREDISCLUSTERDAO_H_
#define YY_STRANGERTALK_GUESSGAME_COMMON_APPREDISCLUSTERDAO_H_

#include <string>
#include <set>
#include <boost/shared_ptr.hpp>

#include "app_common/rediscluster/syncredisclusterclient.h"
#include "utility/json_protobuf_converter.h"

#include "gamedata_redis.pb.h"

using ::yy::common::rediscluster::SyncRedisClusterClient;

using ::protocol::strangertalk::guessgame_redis::GameRoundData;

namespace strangertalk { namespace guessgame { namespace common {

class AppRedisClusterDao {
public:
	AppRedisClusterDao();
	~AppRedisClusterDao();
	bool Init();
	int GetGameRoundData(GameRoundData& data);
	int SetGameRoundData(const GameRoundData& data);
	int DelGameRoundData(uint32_t room_id);
	int GetRoomPeopleList(uint32_t room_id, std::set<uint32_t>& playerlists);
	int GetCompere(uint32_t room_id, uint32_t& compere_uid);
private:
	boost::shared_ptr<SyncRedisClusterClient> sys_redis_cluster_ptr;
	bool init_;
};

}}}
#endif
