#ifndef __SERVER_CUL_MAIXU_QUEUE_H__
#define __SERVER_CUL_MAIXU_QUEUE_H__

#include "CulCommon.h"

namespace server { namespace CUL {

class MaixuQueueChangeObserver
{
	public:
		virtual void onMaixuQueueChange(uint32_t topsid, uint32_t subsid) = 0;
		virtual void onSubscribedMaixu(uint32_t topsid) { };
		virtual void onUnsubscribedMaixu(uint32_t topsid) { };
		virtual ~MaixuQueueChangeObserver(){};
};

class MaixuQueueChange : public CulSubCommon
{
	public:
		// NOTE: usually port = 2066
		MaixuQueueChange(MaixuQueueChangeObserver * o, std::string host, int port);

		// user api
		void subscribeChannel(uint32_t topsid);
		void unsubscribeChannel(uint32_t topsid);

		// pattern sub/unsub all channels
		// NOTE: subscribe all channels need much more bandwith
		//       make sure your process fast enough
		void subscribeAllChannel();
		void unsubscribeAllChannel();

	private:
		// cul should handle those
		virtual void onSub(std::string & ch);
		virtual void onUnsub(std::string & ch);
		virtual void onMsg(std::string & ch, std::string & msg);

		MaixuQueueChangeObserver * m_pObserver;
};

}}

#endif
