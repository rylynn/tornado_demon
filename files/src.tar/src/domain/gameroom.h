/*
 * author:rylynn_xj
 * date: 2015/8/20
 */
#ifndef YY_STRANGERTALK_GUESSGAME_DOMAIN_GAMEROOM_H_
#define YY_STRANGERTALK_GUESSGAME_DOMAIN_GAMEROOM_H_

#include "app_redis_cluster_dao.h"
#include "guessgame.pb.h"
#include "gamedata_redis.pb.h"
#include "syncredisclusterclient.h"

#include <string>
#include <set>
using std::string;
using std::map;
using std::set;

using namespace protocol::strangertalk::guessgame;
using protocol::strangertalk::guessgame_redis::GameRoundData;
using strangertalk::guessgame::common::AppRedisClusterDao;
using ::yy::common::rediscluster::SyncRedisClusterClient;

namespace strangertalk { namespace guessgame { namespace domain {

class GameRoom {
public:
	GameRoom(uint32_t room_id);
	~GameRoom();
	bool Init(AppRedisClusterDao* redis_dao/*,SyncRedisClusterClient* app_cul_redis_dao*/);
	int StartGame(uint32_t compere_uid, uint32_t player_uid,GameSnapShot* gamesnap);
	//int SelectPlayer(uint32_t player_uid,GameSnapShot* gamesnap);
	int EndGame(GameSnapShot* gamesnap);
	int ExitGame(GameSnapShot* gamesnap, uint32_t& _compere_uid);
	int ExitGame(GameSnapShot* gamesnap);
	int NextStep(uint32_t uid, OperatorType op, GameSnapShot* gamesnap);
	int RestartGame(uint32_t uid, GameSnapShot* gamesnap);
	int GetGameStatus(GameSnapShot* gamesnap);

	int GetPeopleOnMicListNum();

	bool CanStartGame(uint32_t player_uid = 0);

	bool CheckCompereOrPlayerLeave();

private:
	bool CompereOrPlayerLeave();
	void ResetGameRoundData();
private:
	bool init_;
	GameRoundData game_round_data_; //one round data
	std::set<string> game_words_;
	AppRedisClusterDao* app_redis_dao_;
	//SyncRedisClusterClient* app_cul_redis_client_;
};

}}}
#endif

