/**
 *author:rylynn_xj
 *date:2015/8/20
 */

#ifndef YY_STRANGERTALK_GUESSGAME_DOMAIN_REPOSITORY_H_
#define YY_STRANGERTALK_GUESSGAME_DOMAIN_REPOSITORY_H_

#include "thread/tssproxy.h"
#include "roomtable.h"

using ::yy::common::thread::TSSProxy;

namespace strangertalk { namespace guessgame { namespace domain { 

class Repository {
public:
	static Repository& Singleton()
	{
		static Repository repository_;
		return repository_;
	}

	TSSProxy<GameRoomTable>& RoomTable(){ return room_table_;}

private:
	Repository();
	~Repository();

private:
	TSSProxy<GameRoomTable> room_table_;
};

}}}
#endif
