#include "miclist_oberserver.h"
#include "log/logger.h"
#include "log/returncodelog.h"
#include "appserverconf.h"

using strangertalk::guessgame::common::AppServerConf;
using strangertalk::guessgame::common::SrvAddress;

namespace strangertalk { namespace guessgame { namespace domain {

MicListObserver::MicListObserver() {
	YY_MEMBER_DEBUG_LOG("[+/-] MicListObserver::ctor()");
}

MicListObserver::~MicListObserver() {
	YY_MEMBER_DEBUG_LOG("[+/-] MicListObserver::dector()");
}

bool MicListObserver::Init(MicListChangeCallBackIf* handler) {
	YY_MEMBER_DEBUG_LOG("[+] MicListObserver::Init()");
	bool ret = false;
	SrvAddress addr;
	AppServerConf::Singleton().GetCulRedisAddr(addr);
	YY_MEMBER_DEBUG_LOG("cul_redis_ip:%s,port:%u",addr.ip.c_str(),addr.port);
	miclist_change_ptr_.reset(new MaixuQueueChange(this, addr.ip, addr.port));
	miclist_change_handler_ptr_ = handler;
	if (miclist_change_handler_ptr_ != NULL && miclist_change_ptr_.get() != NULL) {
		ret = true;
	}
	YY_MEMBER_DEBUG_LOG("[-] MicListObserver::Init(),ret:%d",ret);
	return ret;
}

void MicListObserver::SubscribeRoom(uint32_t room_id) {
	YY_MEMBER_DEBUG_LOG("[+]MicListObserver::SubscribeRoom(),room_id:%u",room_id);
	if(miclist_change_ptr_.get() != NULL)
	{
		miclist_change_ptr_->subscribeChannel(room_id);
	}
	YY_MEMBER_DEBUG_LOG("[-]MicListObserver::SubscribeRoom()");
}

void MicListObserver::CancelSubscribeRoom(uint32_t room_id) {
	YY_MEMBER_DEBUG_LOG("[+]MicListObserver::CancelSubscribeRoom(),room_id:%u",room_id);
	if(miclist_change_ptr_.get() != NULL)
	{
		miclist_change_ptr_->unsubscribeChannel(room_id);
	}
	YY_MEMBER_DEBUG_LOG("[+]MicListObserver::CancelSubscribeRoom(),room_id");
}

void MicListObserver::onMaixuQueueChange(uint32_t topsid, uint32_t subsid) {
	YY_MEMBER_DEBUG_LOG("[+]MicListObserver::onMaixuQueueChange(),topsid:%u,subsid:%u", topsid, subsid);
	miclist_change_handler_ptr_->onMicListChangeHandle(topsid);
	YY_MEMBER_DEBUG_LOG("[-]MicListObserver::onMaixuQueueChange()");
}

}}}

