/*
 * author:rylynn_xj
 * date: 2015/8/20
 */
#ifndef YY_STRANGERTALK_GUESSGAME_DOMAIN_ROOMTABLES_H_
#define YY_STRANGERTALK_GUESSGAME_DOMAIN_ROOMTABLES_H_

#include <map>

#include "gameroom.h"
#include "app_redis_cluster_dao.h"
#include "syncredisclusterclient.h"
#include <boost/shared_ptr.hpp>

using strangertalk::guessgame::common::AppRedisClusterDao; 
using ::yy::common::rediscluster::SyncRedisClusterClient;

namespace strangertalk { namespace guessgame { namespace domain {

class GameRoomTable {
public:
	GameRoomTable();
	~GameRoomTable();
	int GetGameRoom(uint32_t room_id, boost::shared_ptr<GameRoom>& _gameroom);
	//int GetGameRoom(uint32_t room_id, GameRoom* _gameroom) {return 1;}
	int CreateGameRoom(uint32_t room_id);
	int RemoveGameRoom(uint32_t room_id);

private:
	std::map<uint32_t/*room_id*/, boost::shared_ptr<GameRoom> > gameroom_map_;
	boost::shared_ptr<AppRedisClusterDao> app_redis_cluster_dao_ptr_;
	//boost::shared_ptr<SyncRedisClusterClient> app_cul_redis_ptr_;
};

}}}
#endif
