#include "gameroom.h"
#include "log/logger.h"
#include "log/returncodelog.h"
#include "utility/json_protobuf_converter.h"
#include "wordsgenerator.h"
#include "sys/time.h"
#include "shareconst.h"
#include <boost/lexical_cast.hpp>
#include <map>
#include "roomserverandredis.pb.h"

using strangertalk::guessgame::common::WordsGenerator;
using namespace protocol::strangertalk::roomserver::redis;
using ::yy::common::utility::JsonProtobufConverter;

namespace strangertalk { namespace guessgame { namespace domain {
static const uint32_t ON_MAIXU = 3;
static const uint32_t NOT_CARE_PLAYER = 0;

GameRoom::GameRoom(uint32_t room_id):init_(false) {
	YY_MEMBER_DEBUG_LOG("[+/-]GameRoom ctor(),room_id:%u",room_id);
	game_round_data_.set_room_id(room_id);
	game_round_data_.set_game_status(protocol::strangertalk::guessgame_redis::GAME_NOT_START);
	YY_MEMBER_DEBUG_LOG("GameRoom::ctor(),game_round_room_id:%u",game_round_data_.room_id());
}

GameRoom::~GameRoom() {
	YY_MEMBER_DEBUG_LOG("[+/-]GameRoom dector()");
}

bool GameRoom::Init(AppRedisClusterDao* redis_dao) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::Init()");
	if (redis_dao != NULL) {
		app_redis_dao_ = redis_dao;
		init_ = true;
	}
	YY_MEMBER_DEBUG_LOG("[-]GameRoom::Init(),ret:%d",init_);
	return init_;
}

void GameRoom::ResetGameRoundData() {
	YY_MEMBER_DEBUG_LOG("[+/-]GameRoom::ResetGameRoundData()");
	game_round_data_.set_compere_uid(0);
	game_round_data_.set_player_uid(0);
	game_round_data_.set_start_game_time(0);
	game_round_data_.set_correct_count(0);
	game_words_.clear();
}

int GameRoom::StartGame(uint32_t compere_uid, uint32_t player_uid,GameSnapShot* gamesnap) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::StartGame(compere_uid:%u,player_uid:%u)",compere_uid,player_uid);
	int ret = kReturnOk;
	do {
		gamesnap->set_game_status(START_SELECT_PLAYER);

		if (game_round_data_.room_id() != 0 && (compere_uid == 0 || player_uid == 0)) {
			ret = kReturnSysErr;
			YY_MEMBER_LOG(LOG_ERR,"GameRoom::StartGame(),playerid or compereid == 0");
			break;
		}

		if (game_round_data_.has_game_status() && game_round_data_.game_status() != protocol::strangertalk::guessgame_redis::START_SELECT_PLAYER) {
			YY_MEMBER_LOG(LOG_ERR,"GameRoom::Start(),status is error");
			ret = kReturnPermissionDeny;
		}

		if (!CanStartGame(player_uid)) {
			YY_MEMBER_LOG(LOG_ERR,"GameRoom::StartGame(),less than 2 people, or player is not on miclist , so fail to start game");
			ret = kReturnNotEnoughPeople;
			break;
		}


		string word;
		ret = WordsGenerator::Singleton().GetRandomWord(word);

		if (ret != kReturnOk) {
			YY_MEMBER_LOG(LOG_ERR,"GameRoom::StartGame(),getrandomwords error,ret:%d",ret);
			ret = kReturnSysErr;
			break;
		}

		game_words_.insert(word);

		game_round_data_.set_compere_uid(compere_uid);
		struct timeval time_val;
		gettimeofday(&time_val,NULL);
		game_round_data_.set_player_uid(player_uid);
		game_round_data_.set_start_game_time(time_val.tv_sec);
		game_round_data_.set_game_status(protocol::strangertalk::guessgame_redis::START_SELECT_PLAYER);
		game_round_data_.set_word(word);
		
		ret = app_redis_dao_->SetGameRoundData(game_round_data_);
	
		gamesnap->set_system_current_time(time_val.tv_sec);
		gamesnap->set_game_status(GAME_PLAYING);
		gamesnap->set_player_uid(player_uid);
		gamesnap->set_start_time(time_val.tv_sec);
		gamesnap->set_word(word.c_str());
		
	} while(0);

	YY_MEMBER_DEBUG_LOG("[-]GameRoom::StartGame(),ret=>%d",ret);
	RETURN(ret);
}

/*
int GameRoom::SelectPlayer(uint32_t player_uid,GameSnapShot* gamesnap) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::SelectPlayer(player_uid:%u)",game_round_data_.player_uid());
	int ret = kReturnOk;
	do {
		if (game_round_data_.room_id() != 0 && game_round_data_.compere_id() == 0) {
			ret = app_redis_dao->GetGameRoundData(game_round_data_);
			if (ret != kReturnOk) {
				YY_MEMBER_LOG(LOG_ERR,"GameRoom::SelectPlayer(),room_id:%u,GetGameRoundData error,ret:%d",game_round_data_.room_id, ret);
				ret = kReturnSysErr;
				break;
			}
		}

		struct timeval time_val;
		gettimeofday(&time_val,NULL);
		game_round_data_.set_player_uid(player_uid);
		game_round_data_.set_start_game_time(time_val.tv_sec);
		ret = app_redis_dao->SetGameRoundData(game_round_data_);
	} while(0);
	YY_MEMBER_DEBUG_LOG("[-]GameRoom::SelectPlayer()");
	RETURN(ret);
}*/

int GameRoom::EndGame(GameSnapShot* gamesnap) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::EndGame(),room_id:%u,compere_id:%u,player_id:%u", game_round_data_.room_id(), game_round_data_.compere_uid(), game_round_data_.player_uid() );
	int ret = kReturnOk;
	do {
		if (game_round_data_.room_id() != 0 && (!game_round_data_.has_compere_uid() || !game_round_data_.has_player_uid()) ) {
			ret = app_redis_dao_->GetGameRoundData(game_round_data_);
			if (ret != kReturnOk) {
				YY_MEMBER_LOG(LOG_ERR,"GameRoom::SelectPlayer(),room_id:%u,GetGameRoundData error,ret:%d", game_round_data_.room_id(), ret);
				ret = kReturnSysErr;
				break;
			} 
		}

		if (!game_round_data_.has_game_status() || game_round_data_.game_status() != protocol::strangertalk::guessgame_redis::GAME_PLAYING) {
			YY_MEMBER_LOG(LOG_ERR,"GameRoom::Start(),status is error");
			ret = kReturnPermissionDeny;
			break;
		}

		gamesnap->set_game_status(END_GAME);
		gamesnap->set_player_uid(game_round_data_.player_uid());
		gamesnap->set_total_correct_count(game_round_data_.correct_count());
		gamesnap->set_start_time(game_round_data_.start_game_time());

		game_round_data_.set_game_status(protocol::strangertalk::guessgame_redis::END_GAME);

		ResetGameRoundData();
		ret = app_redis_dao_->SetGameRoundData(game_round_data_);
	} while(0);

	YY_MEMBER_DEBUG_LOG("[-]GameRoom::EndGame()");
	RETURN(ret);
}

int GameRoom::ExitGame(GameSnapShot* gamesnap, uint32_t& _compere_uid) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::ExitGame(),room_id:%u",game_round_data_.room_id());
	_compere_uid = game_round_data_.compere_uid();
	ResetGameRoundData();
	game_round_data_.set_game_status(protocol::strangertalk::guessgame_redis::EXIT_GAME);
	gamesnap->set_game_status(EXIT_GAME);
	int ret = app_redis_dao_->DelGameRoundData(game_round_data_.room_id());
	if (ret != kReturnOk) {
		YY_MEMBER_LOG(LOG_ERR,"GameRoom::ExitGame(), room_id:%u exit game error, but game can still go normally",game_round_data_.room_id());
		ret = kReturnOk;
	}
	YY_MEMBER_DEBUG_LOG("[-]GameRoom::ExitGame(),ret:%d",ret);
	RETURN(ret);
}

int GameRoom::ExitGame(GameSnapShot* gamesnap) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::ExitGame(),room_id:%u",game_round_data_.room_id());
	ResetGameRoundData();
	game_round_data_.set_game_status(protocol::strangertalk::guessgame_redis::EXIT_GAME);
	gamesnap->set_game_status(EXIT_GAME);
	int ret = app_redis_dao_->DelGameRoundData(game_round_data_.room_id());
	if (ret != kReturnOk) {
		YY_MEMBER_LOG(LOG_ERR,"GameRoom::ExitGame(), room_id:%u exit game error, but game can still go normally",game_round_data_.room_id());
		ret = kReturnOk;
	}
	YY_MEMBER_DEBUG_LOG("[-]GameRoom::ExitGame(),ret:%d",ret);
	RETURN(ret);
}

int GameRoom::NextStep(uint32_t uid, OperatorType op, GameSnapShot* gamesnap) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::NextStep(),op:%d",op);
	int ret = kReturnOk;
	do {
		if (game_round_data_.room_id() != 0 && (!game_round_data_.has_compere_uid() || !game_round_data_.has_player_uid()) ) {

			ret = app_redis_dao_->GetGameRoundData(game_round_data_);
			if (ret != kReturnOk) {
				YY_MEMBER_LOG(LOG_ERR,"GameRoom::NextStep(),GetCompereUid error,and compere_uid == 0,ret:%u",ret);
				ret = kReturnSysErr;
				break;
			}
		}

		if (!game_round_data_.has_game_status() || game_round_data_.game_status() == protocol::strangertalk::guessgame_redis::END_GAME ||game_round_data_.game_status() == protocol::strangertalk::guessgame_redis::EXIT_GAME ) {
			YY_MEMBER_LOG(LOG_ERR,"GameRoom::Start(),status is error");
			ret = kReturnPermissionDeny;
			break;
		}

		if (game_round_data_.compere_uid() != 0 && game_round_data_.compere_uid() == uid) {

			if (op == CORRECT) {
				game_round_data_.set_correct_count(game_round_data_.correct_count() + 1);
			}
			
			game_round_data_.set_game_status(protocol::strangertalk::guessgame_redis::GAME_PLAYING);

			gamesnap->set_game_status(GAME_PLAYING);
			gamesnap->set_player_uid(game_round_data_.player_uid());
			//gamesnap->set_start_time(game_round_data_.start_game_time());
			std::string randon_word;
			ret = WordsGenerator::Singleton().GetRandomWordNotSame(game_words_,randon_word);
			if (ret != kReturnOk) {
				YY_MEMBER_LOG(LOG_ERR,"GameRoom::NextStep(),get random words error");
				break;
			}

			game_words_.insert(randon_word);
			game_round_data_.set_word(randon_word);
			gamesnap->set_word(randon_word);

			app_redis_dao_->SetGameRoundData(game_round_data_);

			if (ret != kReturnOk) {
				YY_MEMBER_LOG(LOG_ERR,"GameRoom::NextStep() IncCorrectNum error,but game can still play");
			}

		} else {
			ret = kReturnPermissionDeny;
			YY_MEMBER_LOG(LOG_ERR,"not compere send nextstep req");
		}

	} while(0);
	YY_MEMBER_DEBUG_LOG("[-]GameRoom::NextStep,return => %d",ret);
	RETURN(ret);
}

int GameRoom::RestartGame(uint32_t uid, GameSnapShot* gamesnap) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::ResetGame()");
	int ret = kReturnOk;
	do {
		if (game_round_data_.room_id() != 0 && (!game_round_data_.has_compere_uid() || !game_round_data_.has_player_uid())) {
			ret = app_redis_dao_->GetGameRoundData(game_round_data_);
			if (ret != kReturnOk) {
				YY_MEMBER_LOG(LOG_ERR,"GameRoom::NextStep(),GetCompereUid error,and compere_uid == 0,ret:%u",ret);
				ret = kReturnSysErr;
				break;
			}
		}

		if (!game_round_data_.has_game_status() || game_round_data_.game_status() == protocol::strangertalk::guessgame_redis::GAME_NOT_START) {
			YY_MEMBER_LOG(LOG_ERR,"GameRoom::Start(),status is error");
			ret = kReturnPermissionDeny;
			break;
		}

		if (uid != game_round_data_.compere_uid()) {
			YY_MEMBER_DEBUG_LOG("GameRoom::RestartGame(),uid:%u is not compere(%u)",uid,game_round_data_.compere_uid());
			ret = kReturnPermissionDeny;
			break;
		}

		//gamesnap->set_player_uid(game_round_data_.player_uid());
		ResetGameRoundData();
		game_round_data_.set_compere_uid(uid);
		bool result = CanStartGame();
		if (result) {
			game_round_data_.set_game_status(protocol::strangertalk::guessgame_redis::START_SELECT_PLAYER);
			gamesnap->set_game_status(START_SELECT_PLAYER);
		} else {
			game_round_data_.set_game_status(protocol::strangertalk::guessgame_redis::GAME_NOT_START);
			gamesnap->set_game_status(GAME_NOT_START);
		}

		int ret = app_redis_dao_->SetGameRoundData(game_round_data_);
		if (ret == kReturnSysErr) {
			YY_MEMBER_LOG(LOG_ERR,"GameRoom::ResetGame(),compere:%u,room_id:%u restart error,but game can still play",uid,game_round_data_.room_id());
				ret = kReturnOk;
		}

		//ret = StartGame(uid, gamesnap->player_uid(), gamesnap);
	} while(0);

	YY_MEMBER_DEBUG_LOG("[-]GameRoom::ResetGame()");
	return ret;
}

int GameRoom::GetGameStatus(GameSnapShot* gamesnap) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::GetGameStatus()");
	int ret = kReturnOk;
	do {
		if (game_round_data_.room_id() != 0 && ( (game_round_data_.game_status() == protocol::strangertalk::guessgame_redis::GAME_PLAYING  || game_round_data_.game_status() == protocol::strangertalk::guessgame_redis::END_GAME) && !game_round_data_.has_compere_uid()) ) {
			ret = app_redis_dao_->GetGameRoundData(game_round_data_);
			if (ret != kReturnOk) {
				YY_MEMBER_LOG(LOG_ERR,"GameRoom::GetGameStatus(),GetCompereUid error,and compere_uid == 0,ret:%u",ret);
				ret = kReturnSysErr;
				break;
			}
		}

		struct timeval time_val;
		gettimeofday(&time_val,NULL);

		gamesnap->set_system_current_time(time_val.tv_sec); // user-terminal use to calculate time

		if (game_round_data_.has_word()) {
			gamesnap->set_word(game_round_data_.word());
		}
		switch(game_round_data_.game_status()) {
			case protocol::strangertalk::guessgame_redis::GAME_NOT_START:
				{
					bool result = CanStartGame();
					if (result) {
						game_round_data_.set_game_status(protocol::strangertalk::guessgame_redis::START_SELECT_PLAYER);
						gamesnap->set_game_status(START_SELECT_PLAYER);
					} else {
						gamesnap->set_game_status(GAME_NOT_START);
					}
					break;
				}
			case protocol::strangertalk::guessgame_redis::START_SELECT_PLAYER:
				//gamesnap->set_player_uid(game_round_data_.player_uid());
				//gamesnap->set_start_time(game_round_data_.start_game_time());
				gamesnap->set_game_status(START_SELECT_PLAYER);
				break;
			case protocol::strangertalk::guessgame_redis::GAME_PLAYING:
				gamesnap->set_player_uid(game_round_data_.player_uid());
				gamesnap->set_start_time(game_round_data_.start_game_time());
				gamesnap->set_game_status(GAME_PLAYING);
				break;
			case protocol::strangertalk::guessgame_redis::END_GAME:
				gamesnap->set_player_uid(game_round_data_.player_uid());
				gamesnap->set_total_correct_count(game_round_data_.correct_count());
				gamesnap->set_game_status(END_GAME);
				break;
			case protocol::strangertalk::guessgame_redis::EXIT_GAME:
				gamesnap->set_game_status(EXIT_GAME);
				break;
			default:
				ret = kReturnSysErr;
		}

	} while(0);
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::GetGameStatus()");
	RETURN(ret);
}


int GameRoom::GetPeopleOnMicListNum() {
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::GetRoomPeopleNum");
	std::set<uint32_t> players;
	int ret = kReturnOk;
	if (!game_round_data_.has_room_id()) {
		YY_MEMBER_LOG(LOG_ERR,"GameRoom::GetPeopleOnMicListNum(),room_id get error!");
		ret = kReturnSysErr;
		YY_MEMBER_DEBUG_LOG("[+]GameRoom::GetRoomPeopleNum,ret:%d",ret);
		return ret;
	}
	ret = app_redis_dao_->GetRoomPeopleList(game_round_data_.room_id(), players);
	if (ret == kReturnOk) {
		ret = players.size();
	} else {
		YY_MEMBER_LOG(LOG_ERR,"GameRoom::GetRoomPeopleNum, error,ret:%d",ret);
		ret =  kReturnSysErr;
	}
	YY_MEMBER_DEBUG_LOG("[-]GameRoom::GetRoomPeopleNum,ret:%d",ret);
	RETURN(ret);
}

bool GameRoom::CanStartGame(uint32_t player_uid) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::CanStartGame");
	std::set<uint32_t> players;
	bool result = false;
	int ret = kReturnOk;
	if (!game_round_data_.has_room_id()) {
		YY_MEMBER_LOG(LOG_ERR,"GameRoom::CanStartGame(),room_id get error!");
		ret = kReturnSysErr;
		YY_MEMBER_DEBUG_LOG("[+]GameRoom::CanStartGame,ret:%d",ret);
		return ret;
	}
	ret = app_redis_dao_->GetRoomPeopleList(game_round_data_.room_id(), players);
	if (ret == kReturnOk) {
		ret = players.size();
	} else {
		YY_MEMBER_LOG(LOG_ERR,"GameRoom::CanStartGame, error,ret:%d",ret);
		ret =  kReturnSysErr;
	}
	uint32_t compere_uid = 0;
	if (ret >= 2 && app_redis_dao_->GetCompere(game_round_data_.room_id(), compere_uid ) == kReturnOk && (player_uid == NOT_CARE_PLAYER ||  players.find(player_uid) != players.end()) ) {
		result = true;
	}

	YY_MEMBER_DEBUG_LOG("[-]GameRoom::CanStartGame,ret:%d",result);
	return result;
}


bool GameRoom::CheckCompereOrPlayerLeave() {
	YY_MEMBER_DEBUG_LOG("[+]GameRoom::CheckCompereOrPlayerLeave(),room_id:%u",game_round_data_.room_id());
	bool ret = false;

	if (game_round_data_.room_id() != 0 && (game_round_data_.compere_uid() == 0)) {
		ret = app_redis_dao_->GetGameRoundData(game_round_data_);
		if (ret != kReturnOk) {
			YY_MEMBER_LOG(LOG_ERR,"GameRoom::NextStep(),GetCompereUid error,and compere_uid == 0,ret:%u",ret);
			ret = kReturnSysErr;
		}
	}

	if (game_round_data_.game_status() == protocol::strangertalk::guessgame_redis::END_GAME || game_round_data_.game_status() == protocol::strangertalk::guessgame_redis::EXIT_GAME) {
		YY_MEMBER_DEBUG_LOG("[-]GameRoom::CheckCompereOrPlayerLeave(), game not start, so don't care the people change");
		return false;
	}

	std::set<uint32_t> players;
	ret = app_redis_dao_->GetRoomPeopleList(game_round_data_.room_id(), players);

	if (ret == kReturnOk) {
		if ( players.find(game_round_data_.compere_uid() ) == players.end() || players.find(game_round_data_.player_uid()) == players.end()) {
			ret = true;
		}
	} else {
		YY_MEMBER_LOG(LOG_ERR,"GameRoom::CheckCompereOrPlayerLeave(),get playerlist error");
		ret = false;
	}

/*
	string key = kRoomUserPrefix + boost::lexical_cast<string>(game_round_data_.room_id());
	std::map<string, string> results;
	int ret_hgetall = app_redis_dao_->hgetall(key, results);
	bool compere_leave = true;
	bool player_leave = true;

	if (ret_hgetall == 0) 
	{
		for (map<string, string>::iterator iter = results.begin(); iter != results.end(); iter++) 
		{
			R_RoomUser r_room_user;
			if (JsonProtobufConverter<R_RoomUser>::StorageStringToProtobuf(iter->second, r_room_user) != 0) 
			{
				ret = kReturnSysErr;
				break;
			}  

			if(r_room_user.identity_type() == ON_MAIXU)
			{
				if (r_room_user.uid() == game_round_data_.compere_uid()) {
					compere_leave = false;
				}
				if (r_room_user.uid() == game_round_data_.player_uid() ) {
					player_leave = false;
				}
			} 
		}
	} 
	else if (ret_hgetall == -1) 
	{
		YY_MEMBER_LOG(LOG_ERR,"GameRoom::CheckCompereOrPlayerLeave(), cul_redis hget error, key:%s",key.c_str());
		ret = false;
	}
	ret = (compere_leave || player_leave);
	*/
	YY_MEMBER_DEBUG_LOG("[-]GameRoom::CheckCompereOrPlayerLeave(),ret:%d",ret);
	return ret;

}

}}}
