#include "roomtable.h"
#include "log/logger.h"
#include "shareconst.h"
#include "appserverconf.h"

using strangertalk::guessgame::common::AppServerConf;
using strangertalk::guessgame::common::SrvAddress;

namespace strangertalk { namespace guessgame { namespace domain {

GameRoomTable::GameRoomTable() {
	YY_MEMBER_DEBUG_LOG("[+/-]GameRoomTable::ctor()");
	app_redis_cluster_dao_ptr_.reset(new AppRedisClusterDao);
	app_redis_cluster_dao_ptr_->Init();
	//SrvAddress addr;
	//AppServerConf::Singleton().GetCulRedisAddr(addr);
	//app_cul_redis_ptr_.reset(new SyncRedisClusterClient(addr.ip, addr.port));
}

GameRoomTable::~GameRoomTable() {
	YY_MEMBER_DEBUG_LOG("[+/-]GameRoomTable::dector()");
}

int GameRoomTable::GetGameRoom(uint32_t room_id, boost::shared_ptr<GameRoom>& _game_room) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoomTable::GetGameRoom(room_id:%u)",room_id);
	int ret = kReturnOk;
	std::map<uint32_t/*room_id*/, boost::shared_ptr<GameRoom> >::iterator ret_it = gameroom_map_.find(room_id);
	if (ret_it != gameroom_map_.end()) {
		if (ret_it->second.get() != NULL) {
			_game_room = ret_it->second;
		} else {
			YY_MEMBER_LOG(LOG_ERR,"GameRoomTable::GetGameRoom(),room_id:%u pointer is Null",room_id);
		}
		//YY_MEMBER_DEBUG_LOG("GameRoomTable::GetGameRoom(),gameroom_ptr:%x,people_on_mic:%u",_game_room.get(), _game_room->GetPeopleOnMicListNum());
	} else {
		ret = kReturnNotExist;
	}
	YY_MEMBER_DEBUG_LOG("[-]GameRoomTable::GetGameRoom(),ret:%d",ret);
	return ret;
}

int GameRoomTable::CreateGameRoom(uint32_t room_id) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoomTable::CreateGameRoom(room_id:%u)",room_id);
	int ret = kReturnOk;
	std::map<uint32_t/*room_id*/, boost::shared_ptr<GameRoom> >::iterator ret_it = gameroom_map_.find(room_id);
	if (ret_it == gameroom_map_.end()) {
		boost::shared_ptr<GameRoom> game_room_ptr(new GameRoom(room_id));
		//GameRoom* room = new GameRoom(room_id);
		if (game_room_ptr->Init(app_redis_cluster_dao_ptr_.get())) {
			gameroom_map_.insert(std::make_pair(room_id,game_room_ptr));
		} else {
			YY_MEMBER_LOG(LOG_ERR,"GameRoomTable::CreateGameRoom(),redis_cluster init error");
			ret = kReturnSysErr;
		}
	}
	YY_MEMBER_DEBUG_LOG("[-]GameRoomTable::CreateGameRoom(),ret:%d",ret);
	return ret;
}

int GameRoomTable::RemoveGameRoom(uint32_t room_id) {
	YY_MEMBER_DEBUG_LOG("[+]GameRoomTable::RemoveGameRoom(room_id:%u)",room_id);
	int ret = kReturnOk;
	std::map<uint32_t/*room_id*/, boost::shared_ptr<GameRoom> >::iterator ret_it = gameroom_map_.find(room_id);
	if (ret_it == gameroom_map_.end()) {
		ret = kReturnNotExist;
	} else {
		gameroom_map_.erase(ret_it);
	}
	YY_MEMBER_DEBUG_LOG("[-]GameRoomTable::RemoveGameRoom();")
	return ret;
}



}}}
