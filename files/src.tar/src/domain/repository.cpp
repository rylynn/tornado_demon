#include "repository.h"
#include "log/logger.h"

namespace strangertalk { namespace guessgame { namespace domain { 

Repository::Repository() {
	YY_MEMBER_LOG(LOG_INFO,"[+/-]Repository::ctor()");
}

Repository::~Repository() {
	YY_MEMBER_LOG(LOG_INFO,"[+/-]Repository::dector()");
}

}}}
