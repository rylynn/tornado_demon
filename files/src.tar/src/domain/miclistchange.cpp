#include "MaixuQueueChange.h"

using namespace server::CUL;
using namespace server::redis;

	MaixuQueueChange::MaixuQueueChange(MaixuQueueChangeObserver * o, std::string host, int port)
: CulSubCommon(host, port), m_pObserver(o)
{
	//YY_MEMBER_DEBUG_LOG("[+/-]MaixuQueueChange::ctor()");
}

void MaixuQueueChange::subscribeChannel(uint32_t topsid)
{
	fmtkey key("queue_change:");
	key << topsid;
	m_pClient->subscribe(key);
}
void MaixuQueueChange::unsubscribeChannel(uint32_t topsid)
{
	fmtkey key("queue_change:");
	key << topsid;
	m_pClient->unsubscribe(key);
}

void MaixuQueueChange::subscribeAllChannel()
{
	m_pClient->psubscribe("queue_change:*");
}
void MaixuQueueChange::unsubscribeAllChannel()
{
	m_pClient->punsubscribe("queue_change:*");
}

void MaixuQueueChange::onSub(std::string & ch)
{
	const uint32_t PRE_LEN = 13; // the length of "queue_change:" is 13
	if (ch.length() < PRE_LEN+1) {
		log(Warn, "[MaixuQueueChange] channel name format err:%s", ch.c_str());
		return ;
	}
	uint32_t topsid = ::strtoul(ch.data()+PRE_LEN, NULL, 10);
	m_pObserver->onSubscribedMaixu(topsid);
}
void MaixuQueueChange::onUnsub(std::string & ch)
{
	const uint32_t PRE_LEN = 13; // the length of "queue_change:" is 13
	if (ch.length() < PRE_LEN+1) {
		log(Warn, "[MaixuQueueChange] channel name format err:%s", ch.c_str());
		return ;
	}
	uint32_t topsid = ::strtoul(ch.data()+PRE_LEN, NULL, 10);
	m_pObserver->onUnsubscribedMaixu(topsid);
}
void MaixuQueueChange::onMsg(std::string & ch, std::string & msg)
{
	const uint32_t PRE_LEN = 13; // the length of "queue_change:" is 13
	if (ch.length() < PRE_LEN+1) {
		log(Warn, "[MaixuQueueChange] channel name format err:%s", ch.c_str());
		return ;
	}

	char * pNumEnd = NULL;
	uint32_t topsid = ::strtoul(msg.c_str(), &pNumEnd, 10);
	uint32_t subsid = ::strtoul(pNumEnd + 1, NULL, 10);
	m_pObserver->onMaixuQueueChange(topsid, subsid);
}

