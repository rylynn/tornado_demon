/*
 * author:rylynn_xj
 * date: 2015/8/20
 */
#ifndef YY_STRANGERTALK_GUESSGAME_DOMAIN_MICLISTCHANGEOB_H_
#define YY_STRANGERTALK_GUESSGAME_DOMAIN_MICLISTCHANGEOB_H_

#include <boost/shared_ptr.hpp>
#include "miclistchange.h"

namespace server { namespace CUL {
	class MaixuQueueChange;
}}

using namespace ::server::CUL;

namespace strangertalk { namespace guessgame { namespace domain {

class MicListChangeCallBackIf {
public:
	virtual void onMicListChangeHandle(uint32_t room_id) = 0;
	virtual ~MicListChangeCallBackIf(){};
};

class MicListObserver : public MaixuQueueChangeObserver
{
public:
	MicListObserver();
	~MicListObserver();
	bool Init(MicListChangeCallBackIf* handler);
	void SubscribeRoom(uint32_t room_id);
	void CancelSubscribeRoom(uint32_t room_id);
	virtual void onMaixuQueueChange(uint32_t topsid, uint32_t subsid);

private:
	boost::shared_ptr<MaixuQueueChange> miclist_change_ptr_;
	MicListChangeCallBackIf* miclist_change_handler_ptr_;
};

}}}
#endif
