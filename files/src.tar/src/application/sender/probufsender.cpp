/* 
 * File:   probufsender.cpp
 * Author: luoshaoqi
 * 
 * Created on 2015年6月28日, 下午2:41
 */

#include "probufsender.h"
#include <string>
#include "network_if.h"
#include "probufutility.h"
#include "log/logger.h"
#include "itiladapter/agent_client.h"
#include "shareconst.h"

using std::string;
using common::ProbufUtility;
using namespace ::yy::common::itiladapter;

namespace strangertalk { namespace guessgame { namespace application {
  
void ProbufSender::SendUidMsg(uint32_t uid, uint32_t topsid, const Message& message, uint64_t connected_id) {
  YY_DEBUG_LOG("[+]ProbufSender::SendUidMsg(%u, %u ,%s)", uid, topsid, message.ShortDebugString().c_str());
  string resp_str;
  if (ProbufUtility::SerializeToString(message, resp_str) == false) {
    YY_LOG(LOG_ERR, "ProbufSender::SendUidMsg failed to Serialize Response To String, uid:%u", uid);
  } else {
    int32_t send_code = g_ptr_networking->SendUidMsg(uid, topsid, resp_str.data(), resp_str.size(), connected_id);
    if (send_code != 1) {
      YY_LOG(LOG_ERR, "ProbufSender::SendUidMsg failed to send response to client, uid:%u, send_code:%d", uid, send_code);
    }
  }  
  YY_DEBUG_LOG("[-]ProbufSender::SendUidMsg");   
}
    
void ProbufSender::BroadcastBySubchannel(uint32_t tid, uint32_t sid, const Message& message) {
  YY_DEBUG_LOG("[+]ProbufSender::BroadcastBySubchannel(%u, %u, %s)", tid, sid, message.ShortDebugString().c_str());
  string resp_str;
  if (ProbufUtility::SerializeToString(message, resp_str) == false) {
    YY_LOG(LOG_ERR, "ProbufSender::BroadcastBySubchannel failed to Serialize Response To String, tid:%u, sid:%u", tid, sid);
  } else {
    int32_t send_code = g_ptr_networking->BroadcastBySubchannel(tid, sid, resp_str.data(), resp_str.size());
    if (send_code != 1) {
      YY_LOG(LOG_ERR, "ProbufSender::BroadcastBySubchannel failed to send response to client, tid:%u, sid:%u, send_code:%d", tid, sid, send_code);
    }
  }  
  YY_DEBUG_LOG("[-]ProbufSender::BroadcastBySubchannel");  
}

void ProbufSender::UnicastUidMsg(uint32_t uid, const Message& message, uint32_t tid) {
  YY_DEBUG_LOG("[+]ProbufSender::UnicastUidMsg(%u, %s)", uid, message.ShortDebugString().c_str());
  string resp_str;
  if (ProbufUtility::SerializeToString(message, resp_str) == false) {
    YY_LOG(LOG_ERR, "ProbufSender::UnicastUidMsg failed to Serialize Response To String, uid:%u", uid);
  } else {
    int32_t send_code = g_ptr_networking->UnicastUidMsg(uid, resp_str.data(), resp_str.size(), tid);
    if (send_code != 1) {
      YY_LOG(LOG_ERR, "ProbufSender::UnicastUidMsg failed to send response to client, uid:%u, send_code:%d", uid, send_code);
    }
  }  
  YY_DEBUG_LOG("[-]ProbufSender::UnicastUidMsg");    
}

void ProbufSender::BroadcastBySubchannelSeq(uint32_t tid, uint32_t sid, const Message& message) {
  YY_DEBUG_LOG("[+]ProbufSender::BroadcastBySubchannelSeq(%u, %u, %s)", tid, sid, message.ShortDebugString().c_str());
  string resp_str;
  if (ProbufUtility::SerializeToString(message, resp_str) == false) {
    YY_LOG(LOG_ERR, "ProbufSender::BroadcastBySubchannelSeq failed to Serialize Response To String, tid:%u, sid:%u", tid, sid);
  } else {
    int32_t send_code = g_ptr_networking->BroadcastBySubchannelSeq(tid, sid, 0, resp_str.data(), resp_str.size());
    if (send_code != 1) {
      YY_LOG(LOG_ERR, "ProbufSender::BroadcastBySubchannelSeq failed to send response to client, tid:%u, sid:%u, send_code:%d", tid, sid, send_code);
    }
  }  
  YY_DEBUG_LOG("[-]ProbufSender::BroadcastBySubchannelSeq");   
}

}}}
