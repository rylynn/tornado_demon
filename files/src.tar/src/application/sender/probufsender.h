/* 
 * File:   probufsender.h
 * Author: luoshaoqi
 *
 * Created on 2015年6月28日, 下午2:41
 */

#ifndef APPLICATION_SENDER_PROBUFSENDER_H_
#define	APPLICATION_SENDER_PROBUFSENDER_H_

#include <google/protobuf/message.h>

using ::google::protobuf::Message;

namespace strangertalk { namespace guessgame { namespace application {

class ProbufSender {
public:   
  // 功能: 给某个uid发回复消息
 // static void SendUidMsg(uint32_t uid, const Message& message, uint64_t connected_id);

	static void SendUidMsg(uint32_t uid, uint32_t topsid, const Message& message, uint64_t connected_id);
    
  // 功能: 子频道广播, 广播给子频道内所有人
  static void BroadcastBySubchannel(uint32_t tid, uint32_t sid, const Message& message);  
  
  // 功能: 单播给某个uid
  // 说明: 若tid非0, 仅在suid真正在对应频道内时, 才会下发消息到客户端(默认填0)
  static void UnicastUidMsg(uint32_t uid, const Message& message, uint32_t tid = 0);
  
  // 功能: 子频道有序广播, 广播给子频道内所有人
  static void BroadcastBySubchannelSeq(uint32_t tid, uint32_t sid, const Message& message);  
  
private:

};

}}}

#endif	/* APPLICATION_SENDER_PROBUFSENDER_H_ */

