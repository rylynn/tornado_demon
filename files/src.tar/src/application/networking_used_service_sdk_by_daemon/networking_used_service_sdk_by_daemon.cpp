/* 
 * File:   networking_used_service_sdk_by_daemon.cpp
 * Author: liushihai
 * 
 * Created on 2015年5月29日
 */

#include "networking_used_service_sdk_by_daemon.h"
#include "service_sdk_config.h"
#include "svcsdk_aux_daemon.h"

#include <iostream>

#include "server_common/helper/main_inc3.h"
#include "svcsdk.h"

#include "server_common/server-lib/DaemonServer.h"
#include "server_common/server-lib/DaemonServer.h"

using namespace core;
using namespace server;
using namespace sox;


// suid即session uid, 会话uid, 在多点登录的情况下，每个终端suid不一样。对于业务来说，可以把suid理解成为connect id。
static void _onRecvProxyMsg(void * pAppData, uint64_t suid, uint32_t uid,
        uint32_t topsid, uint32_t subsid, const char * data, size_t sz, std::map<uint32_t, std::string> ext)
{
		
		std::cout << "_onRecvProxyMsg suid:" << suid << ",uid:" << uid << std::endl;
    RequestHandlerIf * pThis = static_cast<RequestHandlerIf *>(pAppData);
    pThis->HandleRequest(uid, topsid, subsid, data, sz, suid);
}

NetWorkingUsedServiceSDKByDaemon::NetWorkingUsedServiceSDKByDaemon()
{
}

NetWorkingUsedServiceSDKByDaemon::~NetWorkingUsedServiceSDKByDaemon()
{
}
    
void NetWorkingUsedServiceSDKByDaemon::Run(std::string config_path,int argc, char** argv)
{
  init_daemon dm(argc , argv);
  WrapServerStart::init();

	request_handler_->Init();

  CONFIG_RDAEMON_SERVER_INIT3(config_path, "service_sdk_config",
                              BRouteAppContext,
                              MultiConnManagerImp,
                              InnerConnCreator,
                              InnerConnCreator,
                              BackLinkHandler,
                              RouteWriter,
                              ServiceSKDConfig);


  ///svc sdk initailize
  SVCSDK_ServerPublicData pubData;
  pubData.serviceType = ServiceSKDConfig::service_type();

  SVCSDK_ServerPrivateData priData;
  priData.svcRegKey = ServiceSKDConfig::service_reg_key(); //// NOTE: 平台分配给业务的regKey, 一定是和service type(即app id)是配套的
  priData.bConfigProxy = ServiceSKDConfig::config_proxy();
  priData.bConfigBroadcast = ServiceSKDConfig::config_broadcast();
  priData.bConfigUnicast = ServiceSKDConfig::config_unicast();

  svcsdk_initialize(&pubData, sizeof (pubData), &priData, sizeof (priData));

  svcsdk_subscribe_range(ServiceSKDConfig::subscription_channels_set());

  /// set svc sdk callback
  // 功能: 注册service proxy事件回调
  // 参数: 前4个为相应事件的回调函数指针, 为NULL, 表示忽略和不关心这个事件
  //       最后一个参数pAppData将会在回调函数的第一个参数中传给业务,可以为NULL
  // 说明: 如果某个回调的pAppData不同,那么把其它回调设为NULL,多调几次就行了
  svcsdk_set_proxy_callback(&_onRecvProxyMsg, NULL, NULL, NULL,
                            NULL, NULL, NULL, request_handler_);
  
  // c. svc sdk event helper
  // 获取sdk内部一个eventfd，并添加到业务poll事件循环中，当有事件来时调用svcsdk_poll_event
  // 注意对于daemon和前端网络框架，这个在适配文件中提供给大家了，大家只用创建一个svcsdk_aux_event_helper对象即可
  svcsdk_aux_event_helper __evHelper;
    
  /// svc sdk start
  svcsdk_start();

  // app start
  DAEMON_SERVER_START2;
  WrapServerStart::run();
}
    
int32_t NetWorkingUsedServiceSDKByDaemon::SendUidMsg(uint32_t uid, const char * data, size_t sz, uint64_t connected_id)
{
  return svcsdk_send_uid_msg(connected_id, data, sz);
}

int32_t NetWorkingUsedServiceSDKByDaemon::SendUidMsg(uint32_t uid, uint32_t tid, const char * data, size_t sz, uint64_t connected_id)
{
	return svcsdk_send_uid_msg_tid(connected_id, tid, data, sz);
}

int32_t NetWorkingUsedServiceSDKByDaemon::BroadcastBySubchannel(uint32_t tid, uint32_t sid, const char* data, size_t size)
{
  return svcsdk_bc_sid(tid, sid, data,  size);
}

int32_t NetWorkingUsedServiceSDKByDaemon::BroadcastBySubchannelSeq(uint32_t tid, uint32_t sid, uint32_t opUid, const char* data, size_t size)
{
  return svcsdk_bc_sid_seq(tid, sid, opUid, tid, data, size);
}

int32_t NetWorkingUsedServiceSDKByDaemon::UnicastUidMsg(uint32_t uid, const char * data, size_t size, uint32_t tid) 
{
  return svcsdk_uc_uid_msg(uid, data, size, tid);
}

