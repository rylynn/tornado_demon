/* 
 * File:   service_sdk_config.h
 * Author: liushihai
 *
 * Created on 2015年6月1日
 */

#ifndef SERVICE_SDK_CONFIG_H
#define	SERVICE_SDK_CONFIG_H

#include <inttypes.h>
#include <string>
#include <set>
#include <utility>

#include "server_common/config/IServerConfig.h"
#include "server_common/config/TinyXmlServerConfigImp.h"

using namespace server::config;

class ServiceSKDConfig : public TinyXmlServerConfigImp{
public:
    explicit ServiceSKDConfig(const std::string& path);
    virtual ~ServiceSKDConfig();
    
  // from TinyXmlConfigService
  virtual void loadServer(TiXmlHandle& serverH);
  
  static uint16_t service_type() { return service_type_; }
  static std::string service_reg_key() { return service_reg_key_; }
  static bool config_proxy() { return config_proxy_; }
  static bool config_broadcast() { return config_broadcast_; }
  static bool config_unicast() { return config_unicast_; }
  static std::set<std::pair<uint32_t, uint32_t> > subscription_channels_set() { return subscription_channels_set_; }
private:
   bool LoadServerData(TiXmlHandle& serverH);
    
private:
    static uint16_t service_type_;
    static std::string service_reg_key_;
    static bool config_proxy_;
    static bool config_broadcast_;
    static bool config_unicast_;
    static std::set<std::pair<uint32_t, uint32_t> > subscription_channels_set_; 
};

#endif	/* SERVICE_SDK_CONFIG_H */

