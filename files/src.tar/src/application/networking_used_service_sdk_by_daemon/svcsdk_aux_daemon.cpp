﻿#include "svcsdk_aux_daemon.h"

#include "svcsdk.h"

#include "core/sox/snox.h"

extern uint64_t svcsdk_create_app_group_Id(uint32_t svcType, uint32_t appGroupSeed)
{
    uint64_t outAppGroupId = 0;

    if(svcType == 0)
    {
        return 0;
    }

    if(appGroupSeed == 0)
    {
        return 0;
    }

    outAppGroupId |= ((static_cast<uint64_t>(svcType)) << 32);
    outAppGroupId |= (static_cast<uint64_t>(appGroupSeed) & 0x00000000FFFFFFFFLL);
    return outAppGroupId;
}

struct svcsdk_aux_event_helper::EventChannel : public sox::Socket
{
public:
    EventChannel();
    virtual ~EventChannel();

public:
    // handle event
    virtual void handle(int);
};

svcsdk_aux_event_helper::EventChannel::EventChannel()
{
    int fd = svcsdk_get_eventfd();

    sox::Socket::socket().attach(fd);
    sox::Socket::select(0, sox::SEL_READ);
	log(Info, "select eventfd:%d SEL_READ", fd);
}
svcsdk_aux_event_helper::EventChannel::~EventChannel()
{
    sox::Socket::remove();
}

void svcsdk_aux_event_helper::EventChannel::handle(int)
{
    svcsdk_poll_event();
}


svcsdk_aux_event_helper::EventChannel * svcsdk_aux_event_helper::m_pIns = NULL;
svcsdk_aux_event_helper::svcsdk_aux_event_helper()
{
    if (NULL == m_pIns) {
        m_pIns = new EventChannel();
    }
}

using namespace core;
using namespace server::xlinux;

svcsdk_aux_dispatcher::svcsdk_aux_dispatcher()
{
}
svcsdk_aux_dispatcher::~svcsdk_aux_dispatcher()
{
    ScopedLock<LinuxMutex> lk(m_mtx);

    svcid_connid_t::iterator it = m_mapSvcid2ConnId.begin();
    for (; it != m_mapSvcid2ConnId.end(); ++it) {
        core::IConn * pConn = getConnectById(it->second);
        delete pConn;
    }
    m_mapSvcid2ConnId.clear();
    m_mapConnId2Svcid.clear();
}

uint16_t svcsdk_aux_dispatcher::getServerPort()
{
    if (curports.empty()) {
        log(Fatal, "[dispatcher::getServerPort] call startSV firstly!!!");
        ::exit(-1);
    }
    return curports[0];
}
bool svcsdk_aux_dispatcher::innerDispatch(uint64_t uSvcId, SVCSDK_ServerPublicData * pSvcData, const char* data, size_t size)
{
    bool bIsOk = false;
    ScopedLock<LinuxMutex> lk(m_mtx);

    svcid_connid_t::iterator it = m_mapSvcid2ConnId.find(uSvcId);
    if (it != m_mapSvcid2ConnId.end()) {
        core::IConn * pConn = getConnectById(it->second);
        bIsOk = sendBin(pConn, data, size);
    }
    else {
        if (NULL == pSvcData) {
            SVCSDK_ServerPublicData SvcData;
            if (svcsdk_get_server_by_id(uSvcId, &SvcData)) {
                pSvcData = &SvcData;
            }
            else {
                log(Warn, "[dispatcher::innerDispatch] not found svcId:0x%llx", uSvcId);
            }
        }
        if (NULL != pSvcData) {
            uint16_t uPort = pSvcData->serverTcpPort;
            uint32_t uIp = 0;

            uint32_t uMyIsp = svcsdk_get_my_isp();
            std::map<uint32_t, uint32_t>::iterator ispIt = pSvcData->isp2Ip.find(uMyIsp);
            if (ispIt != pSvcData->isp2Ip.end()) {
                uIp = ispIt->second;
            }
            else if ((ispIt = pSvcData->isp2Ip.begin()) != pSvcData->isp2Ip.end()) {
                uIp = ispIt->second;
            }
            else {
                uIp = svcsdk_get_server_ip(pSvcData->serviceId);
            }

            std::string ip = sox::addr_ntoa(uIp);
            IConn * conn = createClientConn(ip, uPort, handler, this);
            if (NULL != conn) {
                bIsOk = sendBin(conn, data, size);
                uint32_t uConnId = conn->getConnId();
                m_mapSvcid2ConnId[uSvcId] = uConnId;
                m_mapConnId2Svcid[uConnId] = uSvcId;

                log(Notice, "[dispatcher::createClientConn] conn:%p connId:%u svcId:0x%llx ip:%s port:%u",
                        conn, conn->getConnId(), uSvcId, ip.c_str(), uPort);
            }
        }
    }
    
    return bIsOk;
}
bool svcsdk_aux_dispatcher::sendBin(core::IConn *conn, const char* data, size_t size)
{
    try {
        conn->sendBin(data, size, 0);
    }
    catch (std::exception & se) {
        log(Error, "[dispatcher::sendBin] send exception conn:%p connId:%u ip:%s port:%u errMsg:%s data.size:%u", 
                conn, conn->getConnId(), sox::addr_ntoa(conn->getPeerIp()).c_str(), conn->getPeerPort(), se.what(), size);
        DelayDelConn(conn);
        return false;
    }

    return true;
}

void svcsdk_aux_dispatcher::onConnected(core::IConn *conn)
{
    if (conn == NULL) return ;

    ScopedLock<LinuxMutex> lk(m_mtx);
    uint32_t uConnId = conn->getConnId();

    connid_svcid_t::iterator it = m_mapConnId2Svcid.find(uConnId);
    if (it != m_mapConnId2Svcid.end()) {
        log(Notice, "[dispatcher::onConnected] conn:%p connId:%u svcId:0x%llx ip:%s port:%u",
                conn, uConnId, it->second, sox::addr_ntoa(conn->getPeerIp()).c_str(), conn->getPeerPort());
    }

    MultiConnManagerImp::onConnected(conn);
}
void svcsdk_aux_dispatcher::eraseConnect(core::IConn *conn)
{
    if (conn == NULL) return ;

    ScopedLock<LinuxMutex> lk(m_mtx);
    uint32_t uConnId = conn->getConnId();

    connid_svcid_t::iterator it = m_mapConnId2Svcid.find(uConnId);
    if (it != m_mapConnId2Svcid.end()) {
        log(Notice, "[dispatcher::eraseConnect] conn:%p connId:%u svcId:0x%llx ip:%s port:%u",
                conn, uConnId, it->second, sox::addr_ntoa(conn->getPeerIp()).c_str(), conn->getPeerPort());


        m_mapSvcid2ConnId.erase(it->second);
        m_mapConnId2Svcid.erase(it);
    }

    MultiConnManagerImp::eraseConnect(conn);
}

bool svcsdk_aux_dispatcher::answer(core::IConn* pConn, const  std::string & msg)
{
    return answer(pConn, msg.data(), msg.length());
}
bool svcsdk_aux_dispatcher::answer(core::IConn* pConn, uint32_t uri, sox::Marshallable &obj)
{
    Sender sdr(uri, obj);
    sdr.endPack();
    return answer(pConn, sdr.header(), (sdr.headerSize() + sdr.bodySize()));
}
bool svcsdk_aux_dispatcher::answer(core::IConn* pConn, const char * data, uint32_t size)
{
    ScopedLock<LinuxMutex> lk(m_mtx);
    uint32_t uConnId = pConn->getConnId();

    connid_svcid_t::iterator it = m_mapConnId2Svcid.find(uConnId);
    if (it != m_mapConnId2Svcid.end()) {
        return sendBin(pConn, data, size);
    }
    return false;
}

bool svcsdk_aux_dispatcher::dispatchByServiceId(uint64_t serviceId, const  std::string & msg)
{
    return dispatchByServiceId(serviceId, msg.data(), msg.length());
}
bool svcsdk_aux_dispatcher::dispatchByServiceId(uint64_t serviceId, uint32_t uri, sox::Marshallable &obj)
{
    Sender sdr(uri, obj);
    sdr.endPack();

    return dispatchByServiceId(serviceId, sdr.header(), (sdr.headerSize() + sdr.bodySize()));
}
bool svcsdk_aux_dispatcher::dispatchByServiceId(uint64_t serviceId, const char * data, uint32_t size)
{
    return innerDispatch(serviceId, NULL, data, size);
}

bool svcsdk_aux_dispatcher::dispatchToServiceRandom(uint16_t uServiceType, const std::string & msg)
{
    return dispatchToServiceRandom(uServiceType, msg.data(), msg.length());
}
bool svcsdk_aux_dispatcher::dispatchToServiceRandom(uint16_t uServiceType, uint32_t uri, sox::Marshallable &obj)
{
    Sender sdr(uri, obj);
    sdr.endPack();

    return dispatchToServiceRandom(uServiceType, sdr.header(), (sdr.headerSize() + sdr.bodySize()));
}
bool svcsdk_aux_dispatcher::dispatchToServiceRandom(uint16_t uServiceType, const char* data, size_t size)
{
    SVCSDK_ServerPublicData SvcData;
    if (!svcsdk_random_server_by_type(uServiceType, &SvcData)) {
        log(Warn, "[dispatcher::dispatchToServiceRandom] type:%u svc could not be found", uServiceType);
        return false;
    }

    return innerDispatch(SvcData.serviceId, &SvcData, data, size);
}

bool svcsdk_aux_dispatcher::dispatchToServiceRandomInIsp(uint16_t uServiceType, uint32_t uIsp, const std::string & msg)
{
    return dispatchToServiceRandomInIsp(uServiceType, uIsp, msg.data(), msg.length());
}
bool svcsdk_aux_dispatcher::dispatchToServiceRandomInIsp(uint16_t uServiceType, uint32_t uIsp, uint32_t uri, sox::Marshallable &obj)
{
    Sender sdr(uri, obj);
    sdr.endPack();

    return dispatchToServiceRandomInIsp(uServiceType, uIsp, sdr.header(), (sdr.headerSize() + sdr.bodySize()));
}
bool svcsdk_aux_dispatcher::dispatchToServiceRandomInIsp(uint16_t uServiceType, uint32_t uIsp, const char* data, size_t size)
{
    SVCSDK_ServerPublicData SvcData;
    if (!svcsdk_random_server_by_isp(uServiceType, uIsp, &SvcData)) {
        log(Warn, "[dispatcher::dispatchToServiceRandomInIsp] type:%u in isp:%u svc could not be found", uServiceType, uIsp);
        return false;
    }

    return innerDispatch(SvcData.serviceId, &SvcData, data, size);
}

bool svcsdk_aux_dispatcher::dispatchToServiceRandomInGid(uint16_t uServiceType, uint32_t uGid, const std::string & msg)
{
    return dispatchToServiceRandomInGid(uServiceType, uGid, msg.data(), msg.length());
}
bool svcsdk_aux_dispatcher::dispatchToServiceRandomInGid(uint16_t uServiceType, uint32_t uGid, uint32_t uri, sox::Marshallable &obj)
{
    Sender sdr(uri, obj);
    sdr.endPack();

    return dispatchToServiceRandomInGid(uServiceType, uGid, sdr.header(), (sdr.headerSize() + sdr.bodySize()));
}
bool svcsdk_aux_dispatcher::dispatchToServiceRandomInGid(uint16_t uServiceType, uint32_t uGid, const char* data, size_t size)
{
    SVCSDK_ServerPublicData SvcData;
    if (!svcsdk_random_server_by_group(uServiceType, uGid, &SvcData)) {
        log(Warn, "[dispatcher::dispatchToServiceRandomInGid] type:%u in group:%u svc could not be found", uServiceType, uGid);
        return false;
    }

    return innerDispatch(SvcData.serviceId, &SvcData, data, size);
}
