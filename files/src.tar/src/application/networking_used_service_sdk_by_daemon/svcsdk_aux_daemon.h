﻿#ifndef __SVCSDK_DAEMON_EVENT_CHANNEL_HELPER_H__
#define __SVCSDK_DAEMON_EVENT_CHANNEL_HELPER_H__

#include "server_common/server-lib/DaemonServer.h"
#include "server_common/common/LinuxMutex.h"
#include "server_common/common/ScopedLock.h"
#include "core/corelib/MultiConnManagerImp.h"
#include "core/corelib/InnerConn.h"

// 前向申明
class SVCSDK_ServerPublicData;
class svcsdk_aux_dispatcher;

// 成员函数做回调的话, 需要一些trick
// 不过这么做, 要很小心不要把参数传错了, 否则会发生异想不到的运行错误
// 所以还是推荐用全局函数做回调, 然后转调用成员函数
template<typename FromType, typename ToType>
void svcsdk_aux_mem_func(FromType f, ToType & t)
{
    union 
    { 
        FromType _f;
        ToType   _t;
    } ft;

    ft._f = f;
    t = ft._t;
}


extern uint64_t svcsdk_create_app_group_Id(uint32_t svcType, uint32_t appGroupSeed);


// 使用daemon框架封装的svc sdk event
// 请直接使用, 避免重复性劳动
class svcsdk_aux_event_helper
{
public:
    svcsdk_aux_event_helper();

private:
    struct EventChannel;
    static EventChannel * m_pIns;
};

// main里面使用service之间通信
#define SVCSDK_AUX_DISPATCHER(pApp, uServerPort) \
    svcsdk_aux_dispatcher __svcDispatcher; \
    __svcDispatcher.refreshPort(uServerPort); \
    __svcDispatcher.setLinkHandler(&__handler); \
    __svcDispatcher.setConnManager(&__svcDispatcher); \
    __svcDispatcher.setLinkEvent(&__svcDispatcher); \
    __svcDispatcher.setClientConnCreator(&ccreator); \
    __svcDispatcher.setServerConnCreator(&screator); \
    __svcDispatcher.startSV(); \
    (pApp)->setSvcDispatcher(&__svcDispatcher);

// service之间通信, 继承此类
class svcsdk_aux_dispatcher_handler
{
public:
    void setSvcDispatcher(svcsdk_aux_dispatcher * p) { m_pDispatcher = p; }
    svcsdk_aux_dispatcher * getSvcDispatcher() { return m_pDispatcher; }
private:
    svcsdk_aux_dispatcher   * m_pDispatcher;
};
// service之间通信, 使用svc manager的节点发现功, 能根据业务的需求是否使用
// 对于想要通信的svc type需要在sdk初始化的时候加入interestTypes
// 注意: 对于接收的数据消息处理, 需要业务自行实现, 这里只是发送接口
class svcsdk_aux_dispatcher :
    public core::SimplePrxServer,
    public core::MultiConnManagerImp
{
public:
    svcsdk_aux_dispatcher();
    ~svcsdk_aux_dispatcher();

    uint16_t getServerPort();

public:
    // 对外接口 BEGIN ===  // 都是线程安全的接口
    bool answer(core::IConn* pConn, const  std::string & msg);
    bool answer(core::IConn* pConn, uint32_t uri, sox::Marshallable &obj);
    bool answer(core::IConn* pConn, const char * data, uint32_t size);

    bool dispatchByServiceId(uint64_t serviceId, const  std::string & msg);
    bool dispatchByServiceId(uint64_t serviceId, uint32_t uri, sox::Marshallable &obj);
    bool dispatchByServiceId(uint64_t serviceId, const char * data, uint32_t size); 

    bool dispatchToServiceRandom(uint16_t uServiceType, const std::string & msg);
    bool dispatchToServiceRandom(uint16_t uServiceType, uint32_t uri, sox::Marshallable &obj);
    bool dispatchToServiceRandom(uint16_t uServiceType, const char* data, size_t size);

    bool dispatchToServiceRandomInIsp(uint16_t uServiceType, uint32_t uIsp, const  std::string & msg);
    bool dispatchToServiceRandomInIsp(uint16_t uServiceType, uint32_t uIsp, uint32_t uri, sox::Marshallable &obj);    
    bool dispatchToServiceRandomInIsp(uint16_t uServiceType, uint32_t uIsp, const char* data, size_t size);

    bool dispatchToServiceRandomInGid(uint16_t uServiceType, uint32_t uGid, const  std::string & msg);
    bool dispatchToServiceRandomInGid(uint16_t uServiceType, uint32_t uGid, uint32_t uri, sox::Marshallable &obj);
    bool dispatchToServiceRandomInGid(uint16_t uServiceType, uint32_t uGid, const char* data, size_t size);

private:
    bool innerDispatch(uint64_t uSvcId, SVCSDK_ServerPublicData * pSvcData, const char* data, size_t size);
    bool sendBin(core::IConn *conn, const char* data, size_t size);

    virtual void onConnected(core::IConn *conn);
    virtual void eraseConnect(core::IConn *conn);

private:
    typedef std::map<uint64_t, uint32_t>    svcid_connid_t;
    typedef std::map<uint32_t, uint64_t>    connid_svcid_t;

    server::xlinux::LinuxMutex  m_mtx;
    svcid_connid_t  m_mapSvcid2ConnId;
    connid_svcid_t  m_mapConnId2Svcid;
};

#endif

