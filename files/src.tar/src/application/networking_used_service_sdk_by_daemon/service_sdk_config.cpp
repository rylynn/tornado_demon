/* 
 * File:   service_sdk_config.cpp
 * Author: liushihai
 * 
 * Created on 2015年6月1日
 */

#include "service_sdk_config.h"
#include "log/logger.h"
#include "utility/xmlutility.h"

using namespace yy::common::utility;

uint16_t ServiceSKDConfig::service_type_ = 10350;
std::string ServiceSKDConfig::service_reg_key_ = "1c4814e155bd8e0aa57989320eb457a0";
bool ServiceSKDConfig::config_proxy_ =  true;
bool ServiceSKDConfig::config_broadcast_ = true;
bool ServiceSKDConfig::config_unicast_ = true;
std::set<std::pair<uint32_t, uint32_t> > ServiceSKDConfig::subscription_channels_set_;
    
ServiceSKDConfig::ServiceSKDConfig(const std::string& path) : TinyXmlServerConfigImp(path)
{
  //YY_MEMBER_DEBUG_LOG("[+/-]ServiceSKDConfig::ctor");
}

ServiceSKDConfig::~ServiceSKDConfig()
{
  //YY_MEMBER_DEBUG_LOG("[+/-]ServiceSKDConfig::dtor");  
}
    
void ServiceSKDConfig::loadServer(TiXmlHandle& serverH)
{
  //YY_MEMBER_DEBUG_LOG("[+]ServiceSKDConfig::loadServer");
  TinyXmlServerConfigImp::loadServer(serverH);
  if ( LoadServerData(serverH) )
  {
    //YY_MEMBER_DEBUG_LOG("[-]ServiceSKDConfig::loadServer");
    return;
  }
  
  throw std::bad_alloc();
  //YY_MEMBER_DEBUG_LOG("[-]ServiceSKDConfig::loadServer");
}

bool ServiceSKDConfig::LoadServerData(TiXmlHandle& serverH) {
  bool ret = true;

  if (!node_to_int(serverH.FirstChildElement("service_type").Element(), service_type_)) {
    YY_MEMBER_LOG(LOG_ERR, "No service_type");
    ret = false;
  }
  YY_MEMBER_LOG(LOG_INFO, "service_type: %u", service_type_);

  if (!node_to_string(serverH.FirstChildElement("service_reg_key").Element(), service_reg_key_)) {
    YY_MEMBER_LOG(LOG_ERR, "No service_reg_key");
    ret = false;
  }
  YY_MEMBER_LOG(LOG_INFO, "service_reg_key_: %s", service_reg_key_.c_str());

  TiXmlElement* channel_set_elem = serverH.FirstChildElement("subscription_channels").FirstChildElement("channel_set").Element();
  while (channel_set_elem != NULL) {
    uint32_t range_min = 0;
    uint32_t range_max = 0;
    if (!node_to_int(channel_set_elem->FirstChildElement("range_min"), range_min)) {
      YY_MEMBER_LOG(LOG_ERR, "No range_min");
      ret = false;
      break;
    }
    if (!node_to_int(channel_set_elem->FirstChildElement("range_max"), range_max)) {
      YY_MEMBER_LOG(LOG_ERR, "No range_max");
      ret = false;
      break;
    }
    YY_MEMBER_LOG(LOG_INFO, "subscription channels:[%u,%u]", range_min, range_max);
    if (range_min < range_max) {
      subscription_channels_set_.insert(std::make_pair(range_min, range_max));
    } else {
      YY_MEMBER_LOG(LOG_ERR, "%range_min: %u >= range_max: %u", range_min, range_max);
      ret = false;
      break;
    }
    channel_set_elem = channel_set_elem->NextSiblingElement("channel_set");
  }

  return ret;
}

