/* 
 * File:   networking_used_service_sdk_by_daemon.h
 * Author: liushihai
 * Desc:   用service sdk适配NetWorkingIf,同时service sdk运行在daemon体系 
 * Created on 2015年5月29日
 */

#ifndef NETWORKING_USED_SERVICE_SDK_BY_DAEMON_
#define	NETWORKING_USED_SERVICE_SDK_BY_DAEMON_

#include "network_if.h"

class NetWorkingUsedServiceSDKByDaemon : public NetWorkingIf {
public:
    NetWorkingUsedServiceSDKByDaemon();
		virtual ~NetWorkingUsedServiceSDKByDaemon();

		// 功能: 初始化server运行环境：注册service相关信息，type、port等等其它信息
		virtual void Run(std::string config_path,int argc, char** argv);

		// 功能: 给某个uid发回复消息
		virtual int32_t SendUidMsg(uint32_t uid, const char * data, size_t sz, uint64_t connected_id);

		virtual int32_t SendUidMsg(uint32_t uid, uint32_t tid, const char * data, size_t sz, uint64_t connected_id);

			// 功能: 子频道广播, 广播给子频道内所有人
		virtual int32_t BroadcastBySubchannel(uint32_t tid, uint32_t sid, const char* data, size_t size);    

		// 功能: 子频道有序广播, 广播给子频道内所有人
		virtual int32_t BroadcastBySubchannelSeq(uint32_t tid, uint32_t sid, uint32_t opUid, const char* data, size_t size);   

		// 功能: 单播给某个uid
		// 说明: 若tid非0, 仅在suid真正在对应频道内时, 才会下发消息到客户端(一般填0)
		virtual int32_t UnicastUidMsg(uint32_t uid, const char * data, size_t size, uint32_t tid);
};

#endif	/* NETWORKING_USED_SERVICE_SDK_BY_DAEMON_ */

