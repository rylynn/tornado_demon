#include "taskdispatcher.h"
#include <tr1/functional_hash.h>
#include "log/logger.h"
#include "appserverconf.h"

using namespace strangertalk::guessgame::common;
using std::tr1::_Fnv_hash;

namespace strangertalk { namespace guessgame { namespace application {

TaskDispatcher::TaskDispatcher() {
	YY_MEMBER_DEBUG_LOG("[+/-]TaskDispatcher::ctor()");
}

TaskDispatcher::~TaskDispatcher() {
	YY_MEMBER_DEBUG_LOG("[+/-]TaskDispatcher::dector()");
}

bool TaskDispatcher::Init() {
	YY_MEMBER_DEBUG_LOG("[+]TaskDispatcher::Init");  
	bool ret = InitThreadGroups();
	YY_MEMBER_DEBUG_LOG("[-]TaskDispatcher::Init => return %s", ret?"true":"false");
	return ret;
}

bool TaskDispatcher::InitThreadGroups() {
	YY_MEMBER_DEBUG_LOG("[+]TaskDispatcher::InitThreadGroup()");
	bool ret = true;

	const ThreadGroupSet& thread_group_set = AppServerConf::Singleton().thread_group_set();
	for (ThreadGroupSet::const_iterator thread_group = thread_group_set.begin(); thread_group != thread_group_set.end(); thread_group++) {
		string thread_group_name = thread_group->first;
		ThreadGroup threadgroupconf = thread_group->second;
		for (uint32_t task_queue_index = 0; task_queue_index < threadgroupconf.thread_count; ++task_queue_index)
		{
			TaskQueue task_queue(threadgroupconf.alert_queue_size,threadgroupconf.max_queue_size);
			task_queue_map_[thread_group_name][task_queue_index] = task_queue;
		} 
		boost::shared_ptr<AppTaskThreadManager> ptr_thread_manger(new AppTaskThreadManager(
					threadgroupconf.thread_count,
					task_queue_map_[thread_group_name],
					threadgroupconf.thread_threshold,
					thread_group_name
					));
		if (ptr_thread_manger->Init() == false) {
			YY_MEMBER_LOG(LOG_ERR, "TaskDispatcher::InitThreadGroup failed to init AppTaskThreadManager:%s", thread_group_name.c_str());
			ret = false;
			break;
		}
		ptr_thread_manger->Start();
		app_task_thread_manager_map_.insert(make_pair(thread_group_name, ptr_thread_manger));
	}
	YY_MEMBER_DEBUG_LOG("[-]TaskDispatcher::InitThreadGroup => return %s", ret?"true":"false");
	return ret;
}

bool TaskDispatcher::DispatchByRoomId( uint32_t room_id, const string& thread_group_name, Task& task )
{
	YY_MEMBER_DEBUG_LOG("[+]TaskDispatcher::DispatchByRoomId(%u, %s)", room_id, thread_group_name.c_str());
	bool ret = true;
	map<string, map< uint32_t, TaskQueue> >::iterator find =  task_queue_map_.find(thread_group_name);
	if (find != task_queue_map_.end()) {
		uint32_t index = _Fnv_hash::hash(room_id) % find->second.size();
		find->second[(index)].Push(&task);
	} else {
		YY_MEMBER_LOG(LOG_ERR, "CommonTaskSysHandler::Dispatch nuknown thread_group_name:%s", thread_group_name.c_str());
		ret = false;
	}
	YY_MEMBER_DEBUG_LOG("[-]TaskDispatcher::DispatchByRoomId() => return %s", ret?"true":"false");  
	return ret;
}

}}}
