/*
 * author:rylynn_xj
 * date:2015/8/19
 * */

#ifndef YY_STRANGERTALK_GUESSGAME_APPLICATION_APPTASKTHREADMANAGER_H_
#define YY_STRANGERTALK_GUESSGAME_APPLICATION_APPTASKTHREADMANAGER_H_

#include <map>
#include <string>
#include "task/taskthreadmanager.h"
#include "task/taskqueue.h"

using ::yy::common::task::TaskThreadManager;
using ::yy::common::task::TaskQueue;
using ::std::map;
using ::std::string;

namespace strangertalk { namespace guessgame { namespace application {

class AppTaskThreadManager : public TaskThreadManager
{
	public:

		AppTaskThreadManager(
				uint32_t       worker_count,
				map<uint32_t, TaskQueue>&     map_task_queue,
				uint32_t       thread_count_alert_threshold,
				string thread_group_name ="" ) :
			TaskThreadManager(worker_count, map_task_queue),
			thread_count_(0),        
			thread_count_alert_threshold_(thread_count_alert_threshold),
			thread_group_name_(thread_group_name)
	{ /* empty */ };

		virtual ~AppTaskThreadManager() { /* empty */ };

		virtual bool Init();

		void SuperviseThreads();  

		/*void Alert(const string & message);*/

	private:
		uint32_t thread_count_;
		uint32_t thread_count_alert_threshold_;
		string thread_group_name_;

};

}}}
#endif
 
