#include "apptaskthread.h"
#include <stdexcept>
#include "task/task.h"
#include "utility/autodone.h"
#include "log/returncodelog.h"
#include "log/logger.h"
#include "task/taskqueue.h"

using ::yy::common::utility::AutoDone;
using ::yy::common::task::Task;

namespace strangertalk { namespace guessgame { namespace application {

void AppTaskThread::AfterAction()
{
	YY_MEMBER_DEBUG_LOG("[+]AppTaskThread::AfterAction");
	if (this->stop())
	{
		__sync_sub_and_fetch(&thread_count_, 1);
	}
	AutoDone< SimpleLock > guard(lock_, &SimpleLock::Lock, &SimpleLock::Unlock);
	now_task_finshed_count_++;
	YY_MEMBER_DEBUG_LOG("[-]AppTaskThread::AfterAction thread_group:%s, thread_count: %u,"
			"now_task_finshed_count:%u", thread_group_name_.c_str(), thread_count_, now_task_finshed_count_);
}

bool AppTaskThread::Action()
{
	YY_MEMBER_DEBUG_LOG("[+]AppTaskThread::Action");
	Task* tk = task_queue_.Pop();
	if (tk)
	{
		try
		{
			INIT_OR_RRESET_LOG(tk->ToString());
			this->BeforeAction();
			tk->Execute( NULL, NULL );
			tk->Release();     // free relative resource
			tk = NULL;
			this->AfterAction();

			process_count_++;
			const uint32_t kLogThreshold = 1000;
			if (process_count_ >= kLogThreshold) {
				struct timeval now;
				gettimeofday(&now, NULL);
				YY_MEMBER_LOG(LOG_INFO, "AppTaskThread::Action request:%zu, proc:%u, in %zu s, in thread_group:%s",
						task_queue_.size(), process_count_, (now.tv_sec-last_log_timestamp_), thread_group_name_.c_str());
				last_log_timestamp_ = now.tv_sec;
				process_count_ = 0;
			}
		}
		catch ( std::runtime_error& err )
		{
			tk->Release();
			YY_LOG( LOG_ERR, "Thread_group:%s caught std::runtime_error: %s", thread_group_name_.c_str(),err.what() );
		}
		catch (...)
		{
			tk->Release();
			YY_LOG( LOG_ERR, "Thread_group:%s caught Unkown Exception", thread_group_name_.c_str() );
		}
	}
	YY_MEMBER_DEBUG_LOG("[-]AppTaskThread::Action");
	SEND_LOG();
	return true;
}

bool AppTaskThread::IsHealthAndHandleBad()
{
	YY_MEMBER_DEBUG_LOG("[+]AppTaskThread::IsHealthAndHandleBad");
	bool ret = true;
	AutoDone< SimpleLock > guard(lock_, &SimpleLock::Lock, &SimpleLock::Unlock);
	if (now_task_finshed_count_ == last_task_finshed_count_ &&
			!last_quene_is_empty_)
	{
		this->set_stop();
		this->Detach();
		this->set_release();
		ret = false;
	}
	last_task_finshed_count_ = now_task_finshed_count_;
	last_quene_is_empty_ = task_queue_.empty();
	YY_MEMBER_DEBUG_LOG("[-]AppTaskThread::IsHealthAndHandleBad => return %s",
			ret ? "true" : "false");
	return ret;
} 


}}}
