#include "apptaskthreadmanager.h"
#include <assert.h>
#include "log/logger.h"
#include "apptaskthread.h"

namespace strangertalk { namespace guessgame { namespace application {

bool AppTaskThreadManager::Init()
{
	YY_MEMBER_DEBUG_LOG("[+]AppTaskThreadManager::Init");
	AppTaskThread* thr = NULL;
	for ( uint32_t i = 0; i < worker_count_; ++i)
	{
		thr = new AppTaskThread(map_task_queue_[i], thread_count_,thread_group_name_);
		thr->Init();
		workers_.push_back( thr );
	}
	YY_MEMBER_DEBUG_LOG("[-]AppTaskThreadManager::Init => return true");
	return true;
}

void AppTaskThreadManager::SuperviseThreads()
{
	YY_MEMBER_DEBUG_LOG("[+]AppTaskThreadManager::SuperviseThreads");
	AppTaskThread* thr = NULL;
	std::list<TaskThread* >::iterator iter = workers_.begin();
	uint32_t index = 0;

	for (; iter != workers_.end() && index < worker_count_; iter++, index++)
	{
		thr = dynamic_cast<AppTaskThread* >(*iter);
		assert(thr);
		if (!thr->IsHealthAndHandleBad())
		{
			thr = new AppTaskThread(map_task_queue_[index], thread_count_,thread_group_name_);
			thr->Init();
			thr->Start();
			*iter = thr;

			YY_MEMBER_LOG(LOG_ERR, "Alert: thread %u restart, %s", index, thread_group_name_.c_str());
		}  
	}

	uint32_t now_thread_count =  __sync_add_and_fetch(&thread_count_, 0);

	if (now_thread_count > thread_count_alert_threshold_ )
	{
		YY_MEMBER_LOG(LOG_ERR, "Alert: serious thread exception, %s", thread_group_name_.c_str());
	}
	YY_MEMBER_DEBUG_LOG("[-]AppTaskThreadManager::SuperviseThreads"); 
}

}}}
