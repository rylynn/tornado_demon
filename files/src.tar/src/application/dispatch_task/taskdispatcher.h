/*
 *author:rylynn_xj
 *date:2015/8/19
 */

#ifndef YY_STRANGERTALK_GUESSGAME_APPLICATION_TASKDISPATCHER_H_
#define YY_STRANGERTALK_GUESSGAME_APPLICATION_TASKDISPATCHER_H_

#include <map>
#include <string>

#include <boost/shared_ptr.hpp>

#include "task/task.h"
#include "task/taskqueue.h"

#include "apptaskthreadmanager.h"

using std::map;
using boost::shared_ptr;
using ::yy::common::task::Task;
using ::yy::common::task::TaskQueue;

namespace strangertalk { namespace guessgame { namespace application  {

static const std::string kNormalRequestThreadGroup = "NormalRequest";
static const std::string kBroadCastThreadGroup = "Broadcast";

class TaskDispatcher {
public:
	static TaskDispatcher& Singleton()
	{
		static TaskDispatcher singleton_;
		return singleton_;
	}  

	bool Init();
	bool InitThreadGroups();

	bool DispatchByRoomId( uint32_t room_id, const string& thread_group_name, Task& task );  

private:
	TaskDispatcher();
	~TaskDispatcher();
private:
	map<string, map< uint32_t, TaskQueue> > task_queue_map_;
	map<string, boost::shared_ptr<AppTaskThreadManager> >  app_task_thread_manager_map_;
};

}}}

#endif
