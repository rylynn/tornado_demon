/*
 *author:rylynn_xj
 *date:2015/8/19
 * */
#ifndef YY_STRANGERTALK_GUESSGAME_APPLICATION_APPTASKTHREAD_H_
#define YY_STRANGERTALK_GUESSGAME_APPLICATION_APPTASKTHREAD_H_

#include "task/taskthread.h"
#include "task/taskqueue.h"
#include <string>
#include "concurrency/simplelock.h"
#include <sys/time.h>

using std::string;
using ::yy::common::task::TaskThread;
using ::yy::common::task::TaskQueue;
using ::yy::common::concurrency::SimpleLock;

namespace strangertalk { namespace guessgame { namespace application {

class AppTaskThread : public TaskThread {

public:
	AppTaskThread(
			TaskQueue& tq,
			uint32_t& thread_count,
			string thread_group_name="") :
			TaskThread(tq),
			thread_count_(thread_count),   
			last_task_finshed_count_(0),    
			now_task_finshed_count_(0),
			last_quene_is_empty_(true),
			thread_group_name_(thread_group_name),
			process_count_(0), last_log_timestamp_(0)
		{ 
			struct timeval now;
			gettimeofday(&now, NULL); 
			last_log_timestamp_ = now.tv_sec;
		};

	virtual ~AppTaskThread() { /* empty */ };

	bool Init()
	{
		__sync_add_and_fetch (&thread_count_, 1);  
		return true;
	};

	/// from TaskThread
	virtual bool Action();

	void BeforeAction() { /*empty*/ };
	void AfterAction();

	bool IsHealthAndHandleBad();

private:
	uint32_t& thread_count_; 
	uint32_t last_task_finshed_count_;
	uint32_t now_task_finshed_count_;
	bool last_quene_is_empty_;
	string thread_group_name_;
	SimpleLock lock_;  
	uint32_t process_count_;
	uint32_t last_log_timestamp_;
};

}}}

#endif

