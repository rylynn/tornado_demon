#include "nextstepreqtask.h"
#include "log/logger.h"
#include "repository.h"
#include "gameroom.h"
#include "probufsender.h"
#include "shareconst.h"
#include <sstream>
#include <boost/shared_ptr.hpp>
using namespace strangertalk::guessgame::domain;

namespace strangertalk { namespace guessgame { namespace application {

NextStepTask::NextStepTask(uint32_t room_id, uint32_t compere_uid, OperatorType op, uint32_t seq, uint64_t connect_id):room_id_(room_id), compere_uid_(compere_uid), compere_op_(op), seq_(seq), connect_id_(connect_id) {
	YY_MEMBER_DEBUG_LOG("[+/-]NextStepTask::ctor(),room_id:%u,compere_uid:%u,op:%u", room_id, compere_uid, op);
}

NextStepTask::~NextStepTask() {
	YY_MEMBER_DEBUG_LOG("[+/-]NextStepTask::dector()");
}

void NextStepTask::Execute(void* thread_context, void* app_context) {
	YY_MEMBER_DEBUG_LOG("[+]NextStepTask::Execute()");
	GuessGameMsg compere_resp;
	compere_resp.set_uri(PACKET_NEXT_STEP_RESP);
	compere_resp.set_version(1);
	compere_resp.set_seq(seq_);
	NextStepResp* nextstep_resp = compere_resp.mutable_next_step_resp();
	nextstep_resp->set_resp_code(RESP_OK);

	GuessGameMsg bc_resp;
	bc_resp.set_uri(PACKET_GAME_STATUS_BC);
	bc_resp.set_version(1);
	bc_resp.set_seq(seq_);
	GameStatusBC* bc_game_status = bc_resp.mutable_game_status_bc();

	boost::shared_ptr<GameRoom> gameroom;
	int ret = kReturnOk;
	
	ret = Repository::Singleton().RoomTable()->GetGameRoom(room_id_, gameroom);
	if (kReturnOk == ret ) {
		GameSnapShot* gamesnap = bc_game_status->mutable_game_status();
		ret = gameroom->NextStep(compere_uid_, compere_op_, gamesnap);
		if (kReturnOk != ret) {
			YY_MEMBER_DEBUG_LOG("NextStepTask::Execute, room_id_(%u) nextstep error",room_id_);
			nextstep_resp->set_resp_code(RESP_SYS_ERROR);
		}	
	} else {
		YY_MEMBER_DEBUG_LOG("NextStepTask::Execute(),getgameroom error,room_id:%u",room_id_);
		nextstep_resp->set_resp_code(RESP_SYS_ERROR);
	}
	
	YY_MEMBER_DEBUG_LOG("NextStepTask::Execute,send to compere,uid:%u",compere_uid_);
	ProbufSender::SendUidMsg(compere_uid_, room_id_, compere_resp, connect_id_);

	if (ret == kReturnOk) {
		YY_MEMBER_DEBUG_LOG("NextStepTask::Execute,brocast to users");
		ProbufSender::BroadcastBySubchannel(room_id_, room_id_, bc_resp);
	}
}

void NextStepTask::Release() {
	delete this;
}

std::string NextStepTask::ToString() {
	YY_MEMBER_DEBUG_LOG("[+]NextStepTask::ToString()");
	std::stringstream task_info;
	task_info<<"compere_id:"<<compere_uid_<<" room_id:"<<room_id_;
	YY_MEMBER_DEBUG_LOG("[-]NextStepTask::ToString() => return :%s",task_info.str().c_str());
	return task_info.str();
}

}}}
