#include "miclistchangetask.h"
#include "log/logger.h"
#include "repository.h"
#include "gameroom.h"
#include "guessgame.pb.h"
#include "probufsender.h"
#include "shareconst.h"
#include <sys/time.h>
#include <sstream>
#include <boost/shared_ptr.hpp>


using namespace protocol::strangertalk::guessgame;
using strangertalk::guessgame::domain::GameRoom;
using strangertalk::guessgame::domain::Repository;

namespace strangertalk { namespace guessgame { namespace application {

MicListChangeTask::MicListChangeTask(uint32_t room_id):room_id_(room_id) {
	YY_MEMBER_DEBUG_LOG("[+/-]MicListChangeTask::ctor()");
}

MicListChangeTask::~MicListChangeTask(){
	YY_MEMBER_DEBUG_LOG("[+/-]MicListChangeTask::detor()");
}

void MicListChangeTask::Execute(void* thread_context, void* app_context) {
	YY_MEMBER_DEBUG_LOG("[+]MicListChangeTask::Execute()");
	boost::shared_ptr<GameRoom> gameroom;
	if (kReturnOk == Repository::Singleton().RoomTable()->GetGameRoom(room_id_, gameroom) && gameroom->CheckCompereOrPlayerLeave()) {
		YY_MEMBER_DEBUG_LOG("MicListChangeTask::Execute,room_id(%u) compere or player leave room,so stop the game",room_id_);

		struct timeval time_val;
		gettimeofday(&time_val,NULL);
		;

		GuessGameMsg resp_compere;
		GuessGameMsg resp_BC;

		resp_compere.set_uri(PACKET_EXIT_GAME_RESP);
		resp_compere.set_version(1);
		resp_compere.set_seq(time_val.tv_sec);	

		resp_BC.set_uri(PACKET_GAME_STATUS_BC);
		resp_BC.set_version(1);
		resp_BC.set_seq(time_val.tv_sec);	

		ExitGameResp* exit_resp = resp_compere.mutable_exit_game_resp();

		GameStatusBC* gamestatus_bc = resp_BC.mutable_game_status_bc();
		GameSnapShot* gamesnap = gamestatus_bc->mutable_game_status();
		uint32_t compere_uid = 0;
		int ret = gameroom->ExitGame(gamesnap, compere_uid);
		if ( ret == kReturnOk) {
			Repository::Singleton().RoomTable()->RemoveGameRoom(room_id_);
			exit_resp->set_resp_code(RESP_OK);
		} else {
			YY_MEMBER_DEBUG_LOG("MicListChangeTask::Excute(), exit game error,ret:%d",ret);
			exit_resp->set_resp_code(RESP_SYS_ERROR);
		}

		YY_MEMBER_DEBUG_LOG("MicListChangeTask::Execute(), exitgame resp send to compere");
		ProbufSender::UnicastUidMsg(compere_uid, resp_compere, room_id_);

		YY_MEMBER_DEBUG_LOG("MicListChangeTask;:Execute(), exitgame broadcast to people in room");
		ProbufSender::BroadcastBySubchannel(room_id_, room_id_, resp_BC);

		YY_MEMBER_DEBUG_LOG("[-]MicListChangeTask::Execute()");
	} else {
		YY_MEMBER_DEBUG_LOG("MicListChangeTask::Execute(),MicList changed but player and compere not leave");
	}
}

void MicListChangeTask::Release() {
	delete this;
}

std::string MicListChangeTask::ToString() {
	YY_MEMBER_DEBUG_LOG("[+]MicListChangeTask::ToString()");
	std::stringstream task_info;
	task_info<<" room_id:"<<room_id_;
	YY_MEMBER_DEBUG_LOG("[-]MicListChangeTask::ToString() => return :%s",task_info.str().c_str());
	return task_info.str();
}

}}}
