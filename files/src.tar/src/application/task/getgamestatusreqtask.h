/*
 *author:rylynn_xj
 *date:2015/8/26
 * */
#ifndef YY_STRANGERTALK_GUESSGAME_APPLICATION_GETGAMESTATUSREQTASK_H_
#define YY_STRANGERTALK_GUESSGAME_APPLICATION_GETGAMESTATUSREQTASK_H_

#include "task/task.h"
#include <string>

using ::yy::common::task::Task;

namespace strangertalk { namespace guessgame { namespace application {
class GetGameStatusReqTask : public Task {
public:
	GetGameStatusReqTask(uint32_t room_id, uint32_t uid, uint32_t seq, uint64_t connect_id);
	~GetGameStatusReqTask();
	virtual void Execute(
			void*       thread_context,
			void*       app_context);

	virtual void Release();

	virtual std::string ToString();

private:
	uint32_t room_id_;
	uint32_t uid_;
	uint32_t seq_;
	uint32_t connect_id_;
};

}}}
#endif
