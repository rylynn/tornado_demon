/*
 *author:rylynn_xj
 *date:2015/8/25
 * */
#ifndef YY_STRANGERTALK_GUESSGAME_APPLICATION_MICLISTCHANGETASK_H_
#define YY_STRANGERTALK_GUESSGAME_APPLICATION_MICLISTCHANGETASK_H_

#include "task/task.h"
#include <string>

using ::yy::common::task::Task;
namespace strangertalk { namespace guessgame { namespace application {

class MicListChangeTask :public Task {
public:

	MicListChangeTask(uint32_t room_id);
	~MicListChangeTask();

	virtual void Execute(
			void*       thread_context,
			void*       app_context);

	virtual void Release();

	virtual std::string ToString();

private:
	uint32_t room_id_;
};

}}}
#endif

