#include "exitgamereqtask.h"
#include "log/logger.h"
#include "repository.h"
#include "gameroom.h"
#include <sstream>
#include "guessgame.pb.h"
#include "probufsender.h"
#include "shareconst.h"
#include <boost/shared_ptr.hpp>

using namespace protocol::strangertalk::guessgame;
using strangertalk::guessgame::domain::GameRoom;
using strangertalk::guessgame::domain::Repository;

namespace strangertalk { namespace guessgame { namespace application {

ExitGameReqTask::ExitGameReqTask(uint32_t room_id, uint32_t compere_uid, uint32_t seq, uint64_t connect_id, boost::shared_ptr<MicListObserver>& miclist_observer):room_id_(room_id),compere_uid_(compere_uid), seq_(seq), connect_id_(connect_id), miclist_change_observer_ptr_(miclist_observer) {
	YY_MEMBER_DEBUG_LOG("ExitGameReqTask::ctor(),room_id:%u, compere_uid:%u",room_id_,compere_uid);
}

ExitGameReqTask::~ExitGameReqTask() {
	YY_MEMBER_DEBUG_LOG("ExitGameReqTask::dector()");
}

void ExitGameReqTask::Execute(void* thread_context, void* app_context) {
	YY_MEMBER_DEBUG_LOG("ExitGameReqTask::Execute()");
	int ret = kReturnOk;
	GuessGameMsg resp_compere;
	GuessGameMsg resp_BC;

	resp_compere.set_uri(PACKET_EXIT_GAME_RESP);
	resp_compere.set_version(1);
	resp_compere.set_seq(seq_);	

	resp_BC.set_uri(PACKET_GAME_STATUS_BC);
	resp_BC.set_version(1);
	resp_BC.set_seq(seq_);

	EndGameResp* endgame_resp = resp_compere.mutable_end_game_resp();
	endgame_resp->set_resp_code(RESP_OK);

	GameStatusBC* gamestatus_bc = resp_BC.mutable_game_status_bc();
	boost::shared_ptr<GameRoom> gameroom;

	ret = Repository::Singleton().RoomTable()->GetGameRoom(room_id_, gameroom);
	if (kReturnOk == ret) {
		GameSnapShot* gamesnap = gamestatus_bc->mutable_game_status();
		ret = gameroom->ExitGame(gamesnap); // theoryly must return kReturnOk in this logic;
	} else {
		YY_MEMBER_LOG(LOG_ERR,"ExitGameReqTask::Execute,GetGameRoom error,but can still exit game");
		GameSnapShot* gamesnap = gamestatus_bc->mutable_game_status();
		gamesnap->set_game_status(EXIT_GAME);
	}
	YY_MEMBER_DEBUG_LOG("ExitGameReqTask::Execute(),stop subscribe room_id:%u", room_id_);
	miclist_change_observer_ptr_->CancelSubscribeRoom(room_id_);
	ProbufSender::SendUidMsg(compere_uid_, room_id_ ,resp_compere, connect_id_);
	ProbufSender::BroadcastBySubchannel(room_id_, room_id_, resp_BC);
}

void ExitGameReqTask::Release() {
	delete this;
}

std::string ExitGameReqTask::ToString() {
	YY_MEMBER_DEBUG_LOG("[+]ExitGameReqTask::ToString()");
	std::stringstream task_info;
	task_info<<" room_id:"<<room_id_ << "compere_uid"<<compere_uid_;
	YY_MEMBER_DEBUG_LOG("[-]ExitGameReqTask::ToString() => return :%s",task_info.str().c_str());
	return task_info.str();
}

}}}
