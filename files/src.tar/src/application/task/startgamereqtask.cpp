#include "startgamereqtask.h"
#include "log/logger.h"
#include "log/returncode.h"
#include <sstream>
#include "repository.h"
#include "guessgame.pb.h"
#include "gameroom.h"
#include "shareconst.h"
#include "probufsender.h"
#include <boost/shared_ptr.hpp>

namespace strangertalk { namespace guessgame { namespace application {

using namespace protocol::strangertalk::guessgame;
using strangertalk::guessgame::domain::Repository;
using strangertalk::guessgame::domain::GameRoom;

StartGameReqTask::StartGameReqTask(uint32_t compere_id,uint32_t room_id, uint32_t seq, uint32_t player_uid, uint64_t connect_id, boost::shared_ptr<MicListObserver>& miclist_observer):compere_id_(compere_id),room_id_(room_id),connect_id_(connect_id), seq_(seq), player_uid_(player_uid), miclist_change_observer_ptr_(miclist_observer) {
	YY_MEMBER_DEBUG_LOG("[+/-]StartGameReqTask::ctor,compere_id:%u,room_id:%u,player_uid:%u,req.seq:%u,connect_id:%lu",compere_id,room_id,player_uid,seq,connect_id);
}

StartGameReqTask::~StartGameReqTask() {
	YY_MEMBER_DEBUG_LOG("[+/-]StartGameReqTask::dector");
}

void StartGameReqTask::Execute(void* thread_context, void* app_context) {
	YY_MEMBER_DEBUG_LOG("[+]StartGameReqTask::Execute()");
	int ret = kReturnOk;

	GuessGameMsg compere_message;
	GuessGameMsg bc_message;
	compere_message.set_uri(PACKET_START_GAME_RESP);
	compere_message.set_version(1);
	compere_message.set_seq(seq_);

	bc_message.set_uri(PACKET_GAME_STATUS_BC);
	bc_message.set_version(1);
	bc_message.set_seq(seq_);

	StartGameResp* resp = compere_message.mutable_start_game_resp();
	resp->set_resp_code(RESP_OK);
	boost::shared_ptr<GameRoom> game_room_ptr ;
	GameStatusBC* gamestatus_bc = bc_message.mutable_game_status_bc();

	do {
		ret = Repository::Singleton().RoomTable()->GetGameRoom(room_id_, game_room_ptr); 

		if (ret == kReturnNotExist) {
			ret = Repository::Singleton().RoomTable()->CreateGameRoom(room_id_);
			if (ret == kReturnSysErr) {
				YY_MEMBER_LOG(LOG_ERR,"StartGame::Execute(),room_id_:%u create room error",room_id_);
				resp->set_resp_code(RESP_SYS_ERROR);
				break;
			}

			ret = Repository::Singleton().RoomTable()->GetGameRoom(room_id_, game_room_ptr); 
			if (ret == kReturnSysErr) {
				YY_MEMBER_LOG(LOG_ERR,"StartGame::Execute(),get room_error");
				resp->set_resp_code(RESP_SYS_ERROR);
				break;
			}

		}

		//YY_MEMBER_DEBUG_LOG("StartGameReqTask:Execute(),game_room_ptr:%x",game_room_ptr.get());

		if (game_room_ptr.get() != NULL) {
			GameSnapShot* gamesnap = gamestatus_bc->mutable_game_status();
			ret = game_room_ptr->StartGame(compere_id_, player_uid_, gamesnap);
			if (ret == kReturnSysErr) {
				YY_MEMBER_LOG(LOG_ERR,"StartGame error!,room_id:%u,compere_id_:%u",room_id_, compere_id_);
				resp->set_resp_code( RESP_SYS_ERROR);
				break;
			} else if ( ret == kReturnNotEnoughPeople) {
				YY_MEMBER_LOG(LOG_ERR,"StartGame error!,room_id:%u,compere_id_:%u",room_id_, compere_id_);
				resp->set_resp_code(RESP_NOT_ENOUGH_PEOPLE);
			}

		} else {
			YY_MEMBER_LOG(LOG_ERR,"StartGame but people count < 2,room_id:%u,compere_id:%u",room_id_, compere_id_);
			resp->set_resp_code(RESP_PERMISSION_DENY);
		}

	} while(0);

		if (resp->resp_code() == RESP_OK) {
			YY_MEMBER_DEBUG_LOG("StartGameReqTask::Execute(),start to subscribe the room:%u",room_id_);
			miclist_change_observer_ptr_->SubscribeRoom(room_id_);
		}

		YY_MEMBER_DEBUG_LOG("StartGameReqTask::Execute(), exitgame resp send to compere");
		ProbufSender::SendUidMsg(compere_id_, room_id_ ,compere_message, connect_id_);

		if (resp->resp_code() != RESP_SYS_ERROR) {
			YY_MEMBER_DEBUG_LOG("StartGameReqTask;:Execute(), start game broadcast to people in room");
			ProbufSender::BroadcastBySubchannel(room_id_, room_id_, bc_message);
		}

}

void StartGameReqTask::Release() {
	delete this;
}

std::string StartGameReqTask::ToString() {
	YY_MEMBER_DEBUG_LOG("[+]StartGameReqTask::ToString()");
	std::stringstream task_info;
	task_info<<"compere_id:"<<compere_id_<<" room_id:"<<room_id_;
	YY_MEMBER_DEBUG_LOG("[-]StartGameReqTask::ToString() => return :%s",task_info.str().c_str());
	return task_info.str();
}

}}}
