/**
 *author:rylynn_xj
 *date:2015/8/20
 */
#ifndef YY_STRANGERTALK_GUESSGAME_APPLICATION_STARTGAMEREQ_H_
#define YY_STRANGERTALK_GUESSGAME_APPLICATION_STARTGAMEREQ_H_
#include "task/task.h"
#include <string>
#include <boost/shared_ptr.hpp>

#include "miclist_oberserver.h"

using ::yy::common::task::Task;
using strangertalk::guessgame::domain::MicListObserver;
namespace strangertalk { namespace guessgame { namespace application {

class StartGameReqTask : public Task {

public:

	StartGameReqTask(uint32_t compere_id, uint32_t room_id, uint32_t seq, uint32_t player_uid, uint64_t connect_id, boost::shared_ptr<MicListObserver>& miclist_observer);
	~StartGameReqTask();
	virtual void Execute(
			void*       thread_context,
			void*       app_context);

	virtual void Release();

	virtual std::string ToString();

private:
	uint32_t compere_id_;
	uint32_t room_id_;
	uint64_t connect_id_;
	uint32_t seq_;
	uint32_t player_uid_;
	boost::shared_ptr<MicListObserver> miclist_change_observer_ptr_;
};

}}}
#endif
