#include "restartgamereqtask.h"
#include "log/logger.h"
#include "log/returncode.h"
#include <sstream>
#include "repository.h"
#include "guessgame.pb.h"
#include "gameroom.h"
#include "shareconst.h"
#include "probufsender.h"
#include <boost/shared_ptr.hpp>

using namespace protocol::strangertalk::guessgame;
using strangertalk::guessgame::domain::Repository;
using strangertalk::guessgame::domain::GameRoom;

namespace strangertalk { namespace guessgame { namespace application {

RestartGameReqTask::RestartGameReqTask(uint32_t room_id, uint32_t compere_id, uint32_t seq, uint64_t connect_id):room_id_(room_id), compere_uid_(compere_id), seq_(seq), connect_id_(connect_id) {
	YY_MEMBER_DEBUG_LOG("RestartGameReqTask::ctor(),room_id:%u",room_id_);
}

RestartGameReqTask::~RestartGameReqTask() {
	YY_MEMBER_DEBUG_LOG("RestartGameReqTask::dector(),room_id:%u",room_id_);
}

void RestartGameReqTask::Execute(void* thread_context, void* app_context) {
	YY_MEMBER_DEBUG_LOG("RestartGameReqTask::Execute()");
	int ret = kReturnOk;
	GuessGameMsg compere_message;
	GuessGameMsg bc_message;

	compere_message.set_uri(PACKET_RESTART_GAME_RESP);
	compere_message.set_version(1);
	compere_message.set_seq(seq_);

	bc_message.set_uri(PACKET_GAME_STATUS_BC);
	bc_message.set_version(1);
	bc_message.set_seq(seq_);

	RestartGameResp* resp = compere_message.mutable_restart_game_resp();
	resp->set_resp_code(RESP_OK);

	GameStatusBC* gamestatus_bc = bc_message.mutable_game_status_bc();
	boost::shared_ptr<GameRoom> gameroom;

	ret = Repository::Singleton().RoomTable()->GetGameRoom(room_id_, gameroom); 

	if (ret == kReturnOk) {
		GameSnapShot* gamesnap = gamestatus_bc->mutable_game_status();
		ret = gameroom->RestartGame(compere_uid_, gamesnap);

		if (ret == kReturnSysErr) {
			YY_MEMBER_LOG(LOG_ERR,"StartGame::Execute(),room_id_:%u restart error",room_id_);
			resp->set_resp_code(RESP_SYS_ERROR);
		}

		if ( ret == kReturnPermissionDeny) {
			YY_MEMBER_LOG(LOG_ERR,"StartGame::Execute(),room_id_:%u restart error",room_id_);
			resp->set_resp_code(RESP_PERMISSION_DENY);
		}
	}

	YY_MEMBER_DEBUG_LOG("RestartGameReqTask::Execute(),send to compere");
	ProbufSender::SendUidMsg(compere_uid_, room_id_,compere_message, connect_id_);
	if (ret == kReturnOk) {
		ProbufSender::BroadcastBySubchannel(room_id_, room_id_, bc_message);
	}
}

void RestartGameReqTask::Release() {
	delete this;
}

std::string RestartGameReqTask::ToString() {
	YY_MEMBER_DEBUG_LOG("[+]RestartGameReqTask::ToString()");
	std::stringstream task_info;
	task_info<<"compere_id:"<<compere_uid_<<" room_id:"<<room_id_;
	YY_MEMBER_DEBUG_LOG("[-]RestartGameReqTask::ToString() => return :%s",task_info.str().c_str());
	return task_info.str();
}


}}}

