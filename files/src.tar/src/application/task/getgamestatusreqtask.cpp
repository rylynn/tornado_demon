#include "getgamestatusreqtask.h"
#include "log/logger.h"
#include "repository.h"
#include "gameroom.h"
#include "guessgame.pb.h"
#include "probufsender.h"
#include "shareconst.h"
#include <sstream>
#include <boost/shared_ptr.hpp>

using namespace protocol::strangertalk::guessgame;
using strangertalk::guessgame::domain::GameRoom;
using strangertalk::guessgame::domain::Repository;

namespace strangertalk { namespace guessgame { namespace application {

GetGameStatusReqTask::GetGameStatusReqTask(uint32_t room_id, uint32_t uid, uint32_t seq, uint64_t connect_id):room_id_(room_id), uid_(uid), seq_(seq), connect_id_(connect_id) {
	YY_MEMBER_DEBUG_LOG("GetGameStatusReqTask::ctor(),room_id:%u",room_id_);
}

GetGameStatusReqTask::~GetGameStatusReqTask(){
	YY_MEMBER_DEBUG_LOG("GetGameStatusReqTask::dector()");
}

void GetGameStatusReqTask::Execute(void* thread_context, void* app_context) {
	YY_MEMBER_DEBUG_LOG("GetGameStatusReqTask::Execute()");
	int ret = kReturnOk;
	GuessGameMsg resp;
	resp.set_uri(PACKET_GET_GAME_STATUS_RESP);
	resp.set_version(1);
	resp.set_seq(seq_);

	do {
		GetGameStatusResp* gamestatus_resp = resp.mutable_get_game_status_resp();
		gamestatus_resp->set_resp_code(RESP_OK);
		GameSnapShot* gamesnap = gamestatus_resp->mutable_game_status();

		boost::shared_ptr<GameRoom> game_room_ptr;
		ret = Repository::Singleton().RoomTable()->GetGameRoom(room_id_, game_room_ptr);
		if (ret == kReturnOk && game_room_ptr.get() != NULL) {
			ret = game_room_ptr->GetGameStatus(gamesnap);
			if (ret != kReturnOk) {
				gamesnap->set_game_status(GAME_NOT_START);
				gamestatus_resp->set_resp_code(RESP_SYS_ERROR);
			}
		}

		if (ret == kReturnSysErr) {
			gamestatus_resp->set_resp_code(RESP_SYS_ERROR);
			gamesnap->set_game_status(GAME_NOT_START);
			break;
		}

		if (ret == kReturnNotExist){

			ret = Repository::Singleton().RoomTable()->CreateGameRoom(room_id_); 

			if (ret == kReturnSysErr) {
				YY_MEMBER_LOG(LOG_ERR,"StartGame::Execute(),room_id_:%u create room error",room_id_);
				gamestatus_resp->set_resp_code(RESP_SYS_ERROR);
				gamesnap->set_game_status(GAME_NOT_START);
				break;
			}

			ret = Repository::Singleton().RoomTable()->GetGameRoom(room_id_, game_room_ptr); 
			if (ret == kReturnSysErr) {
				YY_MEMBER_LOG(LOG_ERR,"StartGame::Execute(),get room_error");
				gamestatus_resp->set_resp_code(RESP_SYS_ERROR);
				gamesnap->set_game_status(GAME_NOT_START);
				break;
			} 

			ret = game_room_ptr->GetGameStatus(gamesnap);
			if (ret == kReturnSysErr) {
				YY_MEMBER_LOG(LOG_ERR,"GetGameStatusReqTask::Execute(),get game status error room_id:%u",room_id_);
				gamestatus_resp->set_resp_code(RESP_SYS_ERROR);
				break;
			}

			if (gamesnap->game_status() == GAME_NOT_START) {
				gamestatus_resp->set_resp_code(RESP_GAME_NOT_BEGIN);
			}
		}
	} while(0);
	ProbufSender::SendUidMsg(uid_, room_id_, resp, connect_id_);
}

void GetGameStatusReqTask::Release() {
	delete this;
}

std::string GetGameStatusReqTask::ToString() {
	YY_MEMBER_DEBUG_LOG("[+]GetGameStatusReqTask::ToString()");
	std::stringstream task_info;
	task_info<<"uid:"<<uid_<<" room_id:"<<room_id_;
	YY_MEMBER_DEBUG_LOG("[-]GetGameStatusReqTask::ToString() => return :%s",task_info.str().c_str());
	return task_info.str();
}

}}}
