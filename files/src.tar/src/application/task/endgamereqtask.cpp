#include "endgamereqtask.h"
#include "log/logger.h"
#include "repository.h"
#include "gameroom.h"
#include <sstream>
#include "guessgame.pb.h"
#include "probufsender.h"
#include "shareconst.h"
#include <boost/shared_ptr.hpp>

using namespace protocol::strangertalk::guessgame;
using strangertalk::guessgame::domain::GameRoom;
using strangertalk::guessgame::domain::Repository;


namespace strangertalk { namespace guessgame { namespace application {

EndGameReqTask::EndGameReqTask(uint32_t room_id, uint32_t compere_uid, uint32_t seq, uint64_t connect_id):room_id_(room_id),compere_uid_(compere_uid), seq_(seq), connect_id_(connect_id) {
	YY_MEMBER_DEBUG_LOG("EndGameReqTask::ctor(),room_id:%u, compere_uid:%u",room_id_,compere_uid);
}

EndGameReqTask::~EndGameReqTask(){
	YY_MEMBER_DEBUG_LOG("EndGameReqTask::dector()");
}

void EndGameReqTask::Execute(void* thread_context, void* app_context) {
	YY_MEMBER_DEBUG_LOG("EndGameReqTask::Execute()");
	int ret = kReturnOk;
	GuessGameMsg resp_compere;
	GuessGameMsg resp_BC;

	resp_compere.set_uri(PACKET_END_GAME_RESP);
	resp_compere.set_version(1);
	resp_compere.set_seq(seq_);	

	resp_BC.set_uri(PACKET_GAME_STATUS_BC);
	resp_BC.set_version(1);
	resp_BC.set_seq(seq_);

	EndGameResp* endgame_resp = resp_compere.mutable_end_game_resp();
	endgame_resp->set_resp_code(RESP_OK);

	GameStatusBC* gamestatus_bc = resp_BC.mutable_game_status_bc();
	boost::shared_ptr<GameRoom> gameroom;
	ret = Repository::Singleton().RoomTable()->GetGameRoom(room_id_, gameroom);
	if (kReturnOk == ret) {
		GameSnapShot* gamesnap = gamestatus_bc->mutable_game_status();
		ret = gameroom->EndGame(gamesnap);
		if (ret != kReturnOk) {
			YY_MEMBER_LOG(LOG_ERR,"EndGameReqTask::Execute(),something go wrong");
			endgame_resp->set_resp_code(RESP_SYS_ERROR);
		}
	} else {
		YY_MEMBER_LOG(LOG_ERR,"EndGameReqTask::Execute(), get room error,room_id:%u ,ret:%d",room_id_,ret);
	}
	
	YY_MEMBER_DEBUG_LOG("EndGameReqTask::Execute,send to compere");
	ProbufSender::SendUidMsg(compere_uid_, room_id_, resp_compere, connect_id_);
	if (kReturnOk == ret) {
		YY_MEMBER_DEBUG_LOG("EndGameReqTask::Execute(), broadcast to room");
		ProbufSender::BroadcastBySubchannel(room_id_, room_id_, resp_BC);
	}
}

void EndGameReqTask::Release() {
	delete this;
}

std::string EndGameReqTask::ToString() {
	YY_MEMBER_DEBUG_LOG("[+]EndGameReqTask::ToString()");
	std::stringstream task_info;
	task_info<<" room_id:"<<room_id_ << "compere_uid"<<compere_uid_;
	YY_MEMBER_DEBUG_LOG("[-]EndGameReqTask::ToString() => return :%s",task_info.str().c_str());
	return task_info.str();
}

}}}

