/*
 *author:rylynn_xj
 *date:2015/8/26
 * */
#ifndef YY_STRANGERTALK_GUESSGAME_APPLICATION_ENDGAMEREQ_H_
#define YY_STRANGERTALK_GUESSGAME_APPLICATION_ENDGAMEREQ_H_

#include "task/task.h"
#include <string>
#include "guessgame.pb.h"

using ::yy::common::task::Task;
using namespace protocol::strangertalk::guessgame;

namespace strangertalk { namespace guessgame { namespace application {

class EndGameReqTask : public Task {
public:
	EndGameReqTask(uint32_t room_id, uint32_t compere_uid, uint32_t seq, uint64_t connect_id);
	~EndGameReqTask();
	virtual void Execute(
			void*       thread_context,
			void*       app_context);

	virtual void Release();

	virtual std::string ToString();

private:
	uint32_t room_id_;
	uint32_t compere_uid_;
	uint32_t seq_;
	uint64_t connect_id_;
};

}}}
#endif
