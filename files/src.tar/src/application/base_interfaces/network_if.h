/* 
 * File:   network_framework.h
 * Author: Administrator
 *
 * Created on 2015年5月29日, 下午2:28
 */

#ifndef NETWORK_IF_H
#define	NETWORK_IF_H

#include <inttypes.h>
#include <string>
#include "request_handler_if.h"

class NetWorkingIf
{
public:
    NetWorkingIf(){ request_handler_ = NULL; };
    virtual ~NetWorkingIf(){};
    
   // 功能: 初始化server运行环境：注册service相关信息，type、port等等其它信息
   virtual void  Run(std::string config_path,int argc, char** argv) = 0;
    
   // 功能： 设置处理客户端请求的回调函数
   void setRequestHandler(RequestHandlerIf * request_handler) { request_handler_ = request_handler; };
   
   // 功能: 给某个uid发回复消息
   virtual int32_t SendUidMsg(uint32_t uid, uint32_t topsid, const char * data, size_t sz, uint64_t connected_id) =0 ;
    
   // 功能: 子频道广播, 广播给子频道内所有人
   virtual int32_t BroadcastBySubchannel(uint32_t tid, uint32_t sid, const char* data, size_t size) = 0 ;
   
   // 功能: 子频道有序广播, 广播给子频道内所有人
   virtual int32_t BroadcastBySubchannelSeq(uint32_t tid, uint32_t sid, uint32_t opUid, const char* data, size_t size) = 0 ;   
   
   // 功能: 单播给某个uid
   // 说明: 若tid非0, 仅在suid真正在对应频道内时, 才会下发消息到客户端(一般填0)
   virtual int32_t UnicastUidMsg(uint32_t uid, const char * data, size_t size, uint32_t tid) = 0;
   
protected:
    RequestHandlerIf * request_handler_;
};   


extern  NetWorkingIf * const  g_ptr_networking;

#endif	/* NETWORK_IF_H */

