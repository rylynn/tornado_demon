/*
 *author:rylynn_xj
 *date:2015/8/9
 */
#ifndef YY_STRANGERTALK_GUESSGAME_APPLICATION_REQUEST_HANDLER_H_
#define YY_STRANGERTALK_GUESSGAME_APPLICATION_REQUEST_HANDLER_H_
#include  <inttypes.h>
#include <cstddef>

class RequestHandlerIf
{
	public:
		RequestHandlerIf(){}
		virtual ~RequestHandlerIf() { }

		virtual void HandleRequest(uint32_t uid,
				uint32_t topsid, uint32_t subsid, const char * data, size_t sz, uint64_t connected_id) = 0 ;

		virtual void Init() = 0;
};
#endif
