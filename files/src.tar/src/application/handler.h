/*
 *author:rylynn_xj
 *date:2015/8/20
 */

#ifndef YY_STRANGERTALK_GUESSGAME_APPLICATION_HANDLER_H_
#define YY_STRANGERTALK_GUESSGAME_APPLICATION_HANDLER_H_

#include "miclist_oberserver.h"
#include "request_handler_if.h"

#include <boost/shared_ptr.hpp>

using namespace strangertalk::guessgame::domain;
using boost::shared_ptr;

namespace strangertalk { namespace guessgame { namespace application {

class Handler : public RequestHandlerIf , public MicListChangeCallBackIf {
public:
	Handler();
	~Handler();
	void Init();
	virtual void HandleRequest(uint32_t uid, uint32_t topsid, uint32_t subsid, const char * data, size_t sz, uint64_t connected_id);
	virtual void onMicListChangeHandle(uint32_t room_id);
private:
	shared_ptr<MicListObserver> miclist_change_observer_ptr_;
};

}}}
#endif
