#include "handler.h"
#include "taskdispatcher.h"
#include "log/logger.h"
#include "guessgame.pb.h"
#include "pbhelper.h"
#include "probufsender.h"
#include "shareconst.h"

#include "startgamereqtask.h"
#include "miclistchangetask.h"
#include "nextstepreqtask.h"
#include "restartgamereqtask.h"
#include "exitgamereqtask.h"
#include "endgamereqtask.h"
#include "getgamestatusreqtask.h"

using namespace protocol::strangertalk::guessgame;
using strangertalk::guessgame::common::ProtoBufHelper;

namespace strangertalk { namespace guessgame { namespace application {

Handler::Handler() {
	YY_MEMBER_LOG(LOG_INFO,"[+/-]Handler::ctor()");
}

Handler::~Handler() {
	YY_MEMBER_LOG(LOG_INFO,"[+/-]Handler::dector()");
}

void Handler::Init() {
	YY_MEMBER_LOG(LOG_INFO,"[+]Handler::Init()");
	miclist_change_observer_ptr_.reset(new MicListObserver());
	/*
	bool ret = true;
	if (miclist_change_observer_ptr_.get() != NULL) {
		ret = miclist_change_observer_ptr_->Init(this);
	} else {
		ret = false;
	}*/
	YY_MEMBER_LOG(LOG_INFO,"[-]Handler::Init()");
	//return ret;
}

void Handler::HandleRequest(uint32_t uid, uint32_t topsid, uint32_t subsid, const char * data, size_t sz, uint64_t connected_id) {
	YY_MEMBER_DEBUG_LOG("[+]Handler::HandleRequest(uid:%u,topsid:%u,subsid:%u,size:%zu,connect_id:%lu)",uid,topsid,subsid,sz,connected_id);
	std::string message(data, sz);
	GuessGameMsg request;
	GuessGameMsg resp;
	bool resp_immediate = false; 
	if (ProtoBufHelper::StringParseToPb(message, &request) && request.IsInitialized() ) {
		switch (request.uri()) 
		{
			case PACKET_STATRT_GAME_REQ:
				{
					StartGameReqTask* task = new StartGameReqTask(uid, topsid, request.seq(), request.start_game_req().player_uid(), connected_id, miclist_change_observer_ptr_);		
					if (!TaskDispatcher::Singleton().DispatchByRoomId(topsid, kNonBlockThreadGroup, *task)) {
						YY_MEMBER_LOG(LOG_ERR,"Handler::HandleRequest failed to dispatch start-game task,room_id:%u",topsid);
						resp_immediate = true;
						resp.set_uri(PACKET_START_GAME_RESP);
						resp.mutable_start_game_resp()->set_resp_code(RESP_SYS_ERROR);
					 }	
					break;
				}
				
			case PACKET_NEXT_STEP_REQ:
				{
					NextStepTask* task = new NextStepTask(topsid, uid, request.next_step_req().operator_type(), request.seq(), connected_id);
					if (!TaskDispatcher::Singleton().DispatchByRoomId(topsid, kNonBlockThreadGroup, *task)) {
						YY_MEMBER_LOG(LOG_ERR,"Handler::HandleRequest failed to dispatch nextstep task,room_id:%u",topsid);
						resp_immediate = true;
						resp.set_uri(PACKET_START_GAME_RESP);
						resp.mutable_start_game_resp()->set_resp_code(RESP_SYS_ERROR);
					}
					break;
				}

			case PACKET_END_GAME_REQ:
				{
					EndGameReqTask* task = new EndGameReqTask(topsid, uid, request.seq(), connected_id);
					if (!TaskDispatcher::Singleton().DispatchByRoomId(topsid, kNonBlockThreadGroup, *task)) {
						YY_MEMBER_LOG(LOG_ERR,"Handler::HandleRequest failed to dispatch endgamereq task,room_id:%u",topsid);
						resp_immediate = true;
						resp.set_uri(PACKET_START_GAME_RESP);
						resp.mutable_start_game_resp()->set_resp_code(RESP_SYS_ERROR);
					}
					break;
				}

			case PACKET_GET_GAME_STATUS_REQ:
				{
					GetGameStatusReqTask* task = new GetGameStatusReqTask(topsid, uid, request.seq(), connected_id);
					if (!TaskDispatcher::Singleton().DispatchByRoomId(topsid, kNonBlockThreadGroup, *task)) {
						YY_MEMBER_LOG(LOG_ERR,"Handler::HandleRequest failed to dispatch getgamestatus task,room_id:%u",topsid);
						resp_immediate = true;
						resp.set_uri(PACKET_START_GAME_RESP);
						resp.mutable_start_game_resp()->set_resp_code(RESP_SYS_ERROR);
					}
					break;
				}
			case PACKET_EXIT_GAME_REQ:
				{
					ExitGameReqTask* task = new ExitGameReqTask(topsid, uid, request.seq(), connected_id, miclist_change_observer_ptr_);
					if (!TaskDispatcher::Singleton().DispatchByRoomId(topsid, kNonBlockThreadGroup, *task)) {
						YY_MEMBER_LOG(LOG_ERR,"Handler::HandleRequest failed to dispatch ExitGameReq task,room_id:%u", topsid);
						resp_immediate = true;
						resp.set_uri(PACKET_START_GAME_RESP);
						resp.mutable_start_game_resp()->set_resp_code(RESP_SYS_ERROR);
					}
					break;
				}
			case PACKET_RESTART_GAME_REQ:
				{
					RestartGameReqTask* task = new RestartGameReqTask(topsid, uid, request.seq(), connected_id);
					if (!TaskDispatcher::Singleton().DispatchByRoomId(topsid, kNonBlockThreadGroup, *task)) {
						YY_MEMBER_LOG(LOG_ERR,"Handler::HandleRequest failed to dispatch Restart task,room_id:%u",topsid);
						resp_immediate = true;
						resp.set_uri(PACKET_START_GAME_RESP);
						resp.mutable_start_game_resp()->set_resp_code(RESP_SYS_ERROR);
					}
					break;
				}
			default:
				YY_MEMBER_LOG(LOG_ERR,"unknow uri:%u",request.uri());
				break;
		}
	} else {
		resp_immediate = true;
	}

	if (resp_immediate) {
		resp.set_version(request.version());
		resp.set_seq(request.seq());
		YY_MEMBER_DEBUG_LOG("Handler::HandleRequest(),response to uid:%u immediately",uid);
		ProbufSender::SendUidMsg(uid, topsid, resp, connected_id);
	}

	YY_MEMBER_DEBUG_LOG("[-]Handler::HandleRequest()");
}

void Handler::onMicListChangeHandle(uint32_t room_id) {
	YY_MEMBER_DEBUG_LOG("[+]Handler::onMicListChangeHandle(room_id:%u)",room_id);
	MicListChangeTask* task = new MicListChangeTask(room_id);
	if (TaskDispatcher::Singleton().DispatchByRoomId(room_id, kNonBlockThreadGroup, *task)) {
		YY_MEMBER_LOG(LOG_ERR,"Handler::onMicListChangeHandle() task failed to be dispatched");
	}
	YY_MEMBER_DEBUG_LOG("[-]Handler::onMicListChangeHandle()");
}

}}}
