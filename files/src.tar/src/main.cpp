/**
 *author:rylynn_xj
 *date:2015/8/20
 */
 
#include <stdlib.h>
#include <iostream>
#include "network_if.h"
#include "log/logger.h"  
#include "networking_used_service_sdk_by_daemon.h"
#include "handler.h"
#include "appserverconf.h"
#include "wordsgenerator.h"
#include "taskdispatcher.h"

using namespace strangertalk::guessgame::common;
using strangertalk::guessgame::application::Handler;
using strangertalk::guessgame::application::TaskDispatcher;
	
NetWorkingIf * const g_ptr_networking = new NetWorkingUsedServiceSDKByDaemon();

int main(int argc, char** argv) {

	YY_LOG_OPEN( "guessgame_server_d", LOG_PID, LOG_LOCAL0);
	YY_PURE_LOG(LOG_NOTICE, "Now, starting test server...");

	if (AppServerConf::Singleton().Load("../conf/serverconf.cfg") == false) {
		YY_LOG(LOG_ERR, "main(),faile to load AppServerConf");
		return EXIT_FAILURE;    
	}

	if (TaskDispatcher::Singleton().Init() == false) {
		YY_LOG(LOG_ERR, "faile to init TaskDispatcher");
		return EXIT_FAILURE;     
	}

	if (WordsGenerator::Singleton().Init() == false) {
		YY_LOG(LOG_ERR,"main(),failed words generator load");
		return EXIT_FAILURE;
	}

	Handler handler;
	//if (!handler.Init()) {
	//	YY_LOG(LOG_ERR,"main(), handler init error");
	//}

	g_ptr_networking->setRequestHandler(&handler);
	g_ptr_networking->Run("../conf/service_sdk.xml", argc, argv);
	return 0;

}
